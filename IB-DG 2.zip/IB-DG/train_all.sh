mkdir -p logs
export CUDA_VISIBLE_DEVICES=$1
echo Using GPU Device "$1"
export PYTHONUNBUFFERED="True"
export PYTHONWARNINGS='ignore:semaphore_tracker:UserWarning'

LOG="logs/traininginfo.`date +'%Y-%m-%d_%H-%M-%S'`"
exec &> >(tee -a "$LOG")
echo Logging to "$LOG"

#unseen_index=$2
#batch_size=$3
#lr=$4
#task_name=$5
rates=(0.7 0.8 0.9 1)

#for rate in ${rates[@]}
#do
#  for i in $(seq 1 3)
  do
    for index in $(seq 0 3)
    do
    python main1.py $* seed=$i unseen_index=$index starttime=$LOG
#    python main1.py $* seed=$i unseen_index=$index starttime=$LOG ib_rate=$rate
    echo "------------------------"
    done
#  done
#done



import requests

def send_msg_by_serverchan(title, content):
    api = "https://sc.ftqq.com/SCU74559T23c2ae237e89c76a35d19988da2e81565e0ae0b583ace.send"
    data = {
       "text":title,
       "desp":content
    }
    requests.post(api, data=data)
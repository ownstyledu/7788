# import os
# import sys
#
# # os.environ['CUDA_VISIBLE_DEVICES'] = '1'
# import torch
#
# torch.multiprocessing.set_start_method('spawn', force=True)
# import torchvision.transforms as transforms
# from common.dataset import Domain_Specific_Dataset, MultiDataset
# import torchvision.datasets as datasets
# import numpy as np
# from sklearn.metrics import accuracy_score
# import random
# import torch.nn as nn
# # from attn_ib import define_netowrks, Domain_Specific_ResNet, Domain_Specific_AlexNet
# import models
# from common.average_meter import AverageMeter
# import time
# from colorama import Fore, Style
# import torch.nn.functional as F
# from torch.autograd import Variable
# from tensorboardX import SummaryWriter
# from config.cfg_PACS import Config_PACS
# from config.cfg_VLCS import Config_VLCS
#
# import torchvision
# import cv2
# from contiguous_params import ContiguousParams
# from skimage import io
# import torchcam.utils as cam_util
# from torch.utils.data import DataLoader
#
# unloader_img = torchvision.transforms.ToPILImage()
# loader_img = torchvision.transforms.ToTensor()
# device = torch.device('cuda')
#
#
# def main():
#
#     os.environ['CUDA_VISIBLE_DEVICES'] = sys.argv[1]
#     which_cfg = sys.argv[2]
#     if 'vlcs' in which_cfg:
#         cfg = Config_VLCS()
#     else:
#         cfg = Config_PACS()
#     args = sys.argv[1:]
#     print('args:', args)
#     cfg.__setattr__('sys_args', ' '.join(args))
#     for para in args:
#         result = para.split('=')
#         if len(result) == 1:
#             continue
#         if len(result) == 2 and result[0] in cfg.keys():
#             type_param = type(cfg.__getitem__(result[0]))
#             if type_param == bool:
#                 val = eval(result[1])
#             elif type_param == list:
#                 type_elem = type(cfg.__getitem__(result[0])[0])
#                 val = [type_elem(i) for i in result[1].split(',')]
#             else:
#                 val = type_param(result[1])
#             cfg.__setattr__(result[0], val)
#         else:
#             raise ValueError('sys args {0} not supported!!!'.format(para))
#
#     cfg.__setattr__('model_path',
#                     os.path.join('checkpoints/models_unseen', str(cfg.unseen_index), cfg.starttime, str(cfg.seed)))
#     if not os.path.exists(cfg.model_path):
#         os.makedirs(cfg.model_path)
#     cfg.resume_path = os.path.join(cfg.model_path, 'best_model.tar')
#
#     torch.backends.cudnn.deterministic = True
#     torch.backends.cudnn.benchmark = True
#
#     seed = cfg.seed
#     print('seed-----------', seed)
#     random.seed(seed)
#     np.random.seed(seed)
#     torch.manual_seed(seed)
#     torch.cuda.manual_seed_all(seed)
#
#     domains = sorted(os.listdir(cfg.data_root))
#     train_paths = [os.path.join(cfg.data_root, d, 'train') for d in domains if
#                    os.path.isdir(os.path.join(cfg.data_root, d, 'train'))]
#     train_paths.pop(cfg.unseen_index)
#     val_paths = [os.path.join(cfg.data_root, d, 'val') for d in domains if
#                  os.path.isdir(os.path.join(cfg.data_root, d, 'val'))]
#     val_paths.pop(cfg.unseen_index)
#     test_domain = domains[cfg.unseen_index]
#     cfg.__setattr__('test_domain', test_domain)
#     test_path = os.path.join(cfg.data_root, test_domain, 'test')
#
#     if not cfg.train_index:
#         train_domains = sorted(set(domains) ^ set([domains[cfg.unseen_index]]))
#     else:
#         train_domains = cfg.train_index
#
#     cfg.__setattr__('train_domains', train_domains)
#
#     normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
#                                      std=[0.229, 0.224, 0.225])
#     if 'alexnet' in cfg.model:
#         img_size = 227
#     else:
#         img_size = 224
#
#     train_transforms = transforms.Compose([
#         # transforms.Resize(224),
#         # transforms.RandomCrop(224),
#         transforms.RandomResizedCrop(img_size, (0.8, 1)),
#         transforms.RandomHorizontalFlip(),
#         transforms.RandomGrayscale(),
#         transforms.ToTensor(),
#         normalize,
#     ])
#
#     # train_sets = [Domain_Specific_Dataset(cfg, train_p, dom, transforms=train_transforms)
#     #               for train_p, dom in zip(train_paths, train_domains)][0]
#     train_datasets_splits = [Domain_Specific_Dataset(cfg, train_p, dom, transforms=train_transforms)
#                              for train_p, dom in zip(train_paths, train_domains)]
#     train_sets = MultiDataset(*train_datasets_splits)
#
#     test_set = datasets.ImageFolder(test_path, transforms.Compose([
#         transforms.Resize(img_size),
#         transforms.ToTensor(),
#         normalize,
#     ]))
#
#     train_loader = DataLoader(train_sets, batch_size=cfg.batch_size, shuffle=True, num_workers=8, pin_memory=True)
#     val_loader = [DataLoader(
#         datasets.ImageFolder(val_p, transforms.Compose([
#             transforms.Resize(img_size),
#             transforms.ToTensor(),
#             normalize,
#         ])), batch_size=cfg.batch_size, shuffle=False, num_workers=8, pin_memory=True) for val_p in val_paths]
#     test_loader = DataLoader(test_set, batch_size=cfg.batch_size, shuffle=False, num_workers=8, pin_memory=True)
#
#     num_sources = len(train_datasets_splits)
#     cfg.__setattr__('num_sources', num_sources)
#     splits_in_batch = split_integer(cfg.batch_size, num_sources)
#     cfg.__setattr__('splits', splits_in_batch)
#
#     log_path = os.path.join(cfg.writer_path, cfg.task_name + '_' + cfg.starttime)
#     writer = SummaryWriter(logdir=log_path)
#     cfg.__setattr__('log_path', log_path)
#
#     # model
#     model = models.define_netowrks(cfg).to(device)
#     ds_model = models.DS_Model(cfg).to(device)
#
#     parameters = ContiguousParams(model.parameters())
#     optimizer = torch.optim.SGD(parameters.contiguous(), lr=cfg.lr, momentum=cfg.momentum,
#                                 weight_decay=cfg.weight_decay)
#     optimizer_ds = torch.optim.SGD(ds_model.parameters(), lr=cfg.lr_ds, momentum=cfg.momentum,
#                                    weight_decay=cfg.weight_decay)
#
#     scheduler = get_scheduler(cfg, optimizer)
#     scheduler_ds = get_scheduler(cfg, optimizer_ds)
#
#     # loss
#     loss_fn = torch.nn.CrossEntropyLoss().to(device)
#
#     best_acc = 0.0
#     best_acc_from_val = 0.0
#     best_val = 0.0
#
#     loss_dict = {
#         'loss_ds': AverageMeter(),
#         'loss_main_ds': AverageMeter(),
#         'loss_ib_feat': AverageMeter(),
#         'loss_feat_mix': AverageMeter(),
#         'loss_ib_cls': AverageMeter()
#     }
#
#     for ite, (d1, d2, d3) in enumerate(train_loader):
#
#         if ite >= cfg.loops_train:
#             if writer is not None:
#                 writer.close()
#             break
#
#         start_time = time.time()
#         model.train()
#         ds_model.train()
#
#         for data in (d1, d2, d3):
#             data[0] = data[0].to(device)
#             data[1] = data[1].to(device)
#
#         if 'dropout' in cfg.model and cfg.change_dropout_rate:
#             if random.random() > cfg.ib_rate:
#                 model.change_dropout(model.main_net, 0)
#             else:
#                 model.change_dropout(model.main_net, cfg.ib_rate)
#
#         if cfg.ds and ite < cfg.ds_ite_end:
#             total_loss_ds = 0
#             for index, (images, labels, _, _) in enumerate([d1, d2, d3]):
#
#                 ds_net = ds_model.ds_nets[index]
#                 result_ds = ds_net(images)
#                 loss_ds = loss_fn(result_ds['cls'], labels) * cfg.alpha_ds
#                 total_loss_ds += loss_ds
#                 loss_dict['loss_ds'].update(loss_ds.item())
#
#                 if cfg.vis and ite % cfg.print_freq == 0:
#                     add_imgs(writer, images, 'train_image_ds', ite + index)
#
#             optimizer_ds.zero_grad()
#             total_loss_ds.backward()
#             optimizer_ds.step()
#
#         # cfg.__setattr__('ib_rate', (ite / cfg.loops_train))
#         #ib_flag = cfg.ib_feat and ite >= cfg.ib_ite_start
#         ib_flag = cfg.ib_feat and ite >= cfg.ib_ite_start and random.random() <= cfg.ib_rate
#         if ib_flag:
#             total_loss = 0
#             candidates = list(np.arange(0, cfg.num_sources))
#             for index, (images, labels, _, path) in enumerate([d1, d2, d3]):
#
#                 if index in cfg.exclude_index:
#                     continue
#
#                 index_cross, gated_strategy, ib_interact, act_area, ib_layers = get_gating_settings(cfg, index, candidates)
#                 if cfg.ib_type == 'g':
#                     result = model.forward_ib_grad(images, index_cross=index_cross, labels=labels, act_area=act_area,
#                                        ib_layers=ib_layers, ds_model=ds_model, gated_strategy=gated_strategy, current_index=index)
#                 else:
#                     result = model.forward_ib_grad_a(images, index_cross=index_cross, labels=labels, act_area=act_area,
#                                                    ib_layers=ib_layers, ds_model=ds_model,
#                                                    gated_strategy=gated_strategy, current_index=index)
#
#                 loss_ib_feat = loss_fn(result['cls'], labels) * cfg.alpha_ib
#                 if cfg.flood > 0:
#                     loss_ib_feat = (loss_ib_feat - cfg.flood).abs() + cfg.flood
#                 total_loss += loss_ib_feat
#                 loss_dict['loss_ib_feat'].update(loss_ib_feat.item())
#
#                 if ite % 50 == 0:
#                     for key, val in result.items():
#                         if 'ib_preserve_rate' in key:
#                             print('ite {0} {1}: training {2} with {3}({4}/{5}){6} is {7}'.format(
#                                 ite, key, cfg.train_domains[index],
#                                 [cfg.train_domains[d] for d in index_cross],
#                                 ib_interact, gated_strategy, act_area,
#                                 round(val, 5)))
#
#                 if cfg.vis and ite % cfg.print_freq == 0:
#                     add_imgs(writer, images, 'train_image_ib', ite + index)
#
#                 if cfg.vis_cam and ite % cfg.print_freq == 0:
#                     vis_cam(ite, cfg, model, result, images, path, ib_layers[-1], index, index_cross, writer)
#
#             optimizer.zero_grad()
#             total_loss.backward()
#             optimizer.step()
#
#         elif cfg.mix and ite <= cfg.mix_ite_end:
#
#             total_loss = 0
#
#             list_imgs = []
#             list_labels = []
#             for index, (images, labels, _, _) in enumerate([d1, d2, d3]):
#
#                 list_imgs.append(images)
#                 list_labels.append(labels)
#
#             imgs_mixed = torch.cat(list_imgs, dim=0)
#             tgts_mixed = torch.cat(list_labels, dim=0)
#
#             imgs_index = [i for i in range(imgs_mixed.size()[0])]
#             random.shuffle(imgs_index)
#             imgs_mixed = imgs_mixed[imgs_index]
#             tgts_mixed = tgts_mixed[imgs_index]
#
#             for i in range(cfg.num_sources):
#
#                 imgs = imgs_mixed[i * cfg.batch_size: (1 + i) * cfg.batch_size, :]
#                 tgts = tgts_mixed[i * cfg.batch_size: (1 + i) * cfg.batch_size]
#                 result = model(imgs, dropout=cfg.dropout)
#
#                 loss_mix = loss_fn(result['cls'], tgts) * cfg.alpha_mix
#                 total_loss += loss_mix
#                 loss_dict['loss_feat_mix'].update(loss_mix.item())
#
#             optimizer.zero_grad()
#             total_loss.backward()
#             optimizer.step()
#
#             if cfg.vis and ite % cfg.print_freq == 0:
#                 add_imgs(writer, imgs, 'train_image_mix', ite)
#
#         elif cfg.main_ds:
#
#             total_loss = 0
#             for index, (images, labels, _, path) in enumerate([d1, d2, d3]):
#
#                 result = model(images, dropout=cfg.dropout)
#                 loss_main_ds = loss_fn(result['cls'], labels) * cfg.alpha_main_ds
#                 total_loss += loss_main_ds
#                 loss_dict['loss_main_ds'].update(loss_main_ds.item())
#
#                 if cfg.vis and ite % cfg.print_freq == 0:
#                     add_imgs(writer, images, 'train_image_main_ds', ite + index)
#
#             optimizer.zero_grad()
#             total_loss.backward()
#             optimizer.step()
#
#         elif cfg.mix_ib and ite <= cfg.mix_ite_end:
#
#             list_imgs = []
#             list_labels = []
#             for index, (images, labels, _, _) in enumerate([d1, d2, d3]):
#
#                 list_imgs.append(images)
#                 list_labels.append(labels)
#
#             imgs_mixed = torch.cat(list_imgs, dim=0)
#             tgts_mixed = torch.cat(list_labels, dim=0)
#
#             imgs_index = [i for i in range(imgs_mixed.size()[0])]
#             random.shuffle(imgs_index)
#             imgs_mixed = imgs_mixed[imgs_index]
#             tgts_mixed = tgts_mixed[imgs_index]
#
#             for i in range(cfg.num_sources):
#
#                 candidates = list(np.arange(0, cfg.num_sources))
#                 index_cross, gated_strategy, ib_interact, act_area, ib_layers = get_gating_settings(cfg, i,
#                                                                                                     candidates)
#
#                 images = imgs_mixed[i * cfg.batch_size: (1 + i) * cfg.batch_size, :]
#                 labels = tgts_mixed[i * cfg.batch_size: (1 + i) * cfg.batch_size]
#                 result = model.forward_ib_grad(images, index_cross=index_cross, labels=labels, act_area=act_area,
#                                                ib_layers=ib_layers, ds_model=ds_model, gated_strategy=gated_strategy,
#                                                current_index=i)
#
#                 loss_mix = loss_fn(result['cls'], labels) * cfg.alpha_mix
#                 loss_dict['loss_ib_feat'].update(loss_mix.item())
#
#                 optimizer.zero_grad()
#                 loss_mix.backward()
#                 optimizer.step()
#
#                 if ite % 50 == 0:
#                     for key, val in result.items():
#                         if 'ib_preserve_rate' in key:
#                             print('ite {0} {1}: training {2} with {3}({4}/{5}){6} is {7}'.format(
#                                 ite, key, cfg.train_domains[i],
#                                 [cfg.train_domains[d] for d in index_cross],
#                                 ib_interact, gated_strategy, act_area,
#                                 round(val, 5)))
#
#             if cfg.vis and ite % cfg.print_freq == 0:
#                 add_imgs(writer, images, 'train_image_mix_ib', ite)
#
#         if ite > 0 and ite % cfg.print_freq == 0:
#             cfg.__setattr__('current_lr', format(optimizer.param_groups[0]['lr'], '.3e'))
#             print_errors(ite, cfg, loss_dict, optimizer, optimizer_ds)
#             print('iters: {0}/{1}'.format(ite, cfg.loops_train),
#                   Fore.CYAN, 'log_path:{0}'.format(cfg.log_path), Style.RESET_ALL
#                   )
#             print('100 ites training time: {0}s'.format((time.time() - start_time) * 100))
#
#             ### test domain specific networks on val sets
#             val_acc = val_workflow(cfg, model, val_loader, ds_model)
#
#             ### test main model
#             test_acc = test_workflow(cfg, model, ite, test_loader, writer, val_acc)
#             if val_acc > best_val:
#                 best_val = val_acc
#                 best_acc_from_val = test_acc
#
#             if test_acc > best_acc:
#                 best_acc = test_acc
#                 if cfg.save_model:
#                     outfile = os.path.join(cfg.model_path, 'best_model_for_{0}.tar'.format(cfg.test_domain))
#                     torch.save({'ite': ite, 'seed': cfg.seed, 'unseen': cfg.test_domain,
#                                 'state': model.state_dict()},
#                                outfile)
#
#             print(Fore.YELLOW,
#                   'seed {0}: best dg test accuracy is //////{1}//////, best dg test acc from val is //////{2}////// (val:{3})'
#                   .format(cfg.seed, round(best_acc * 100, 3), round(best_acc_from_val * 100, 3), round(best_val * 100, 3)),
#                   Style.RESET_ALL)
#
#         scheduler.step()
#
#         if cfg.ds and ite <= cfg.ds_ite_end:
#             scheduler_ds.step()
#
#         parameters.assert_buffer_is_valid()
#
#
#
#
# def print_errors(ite, cfg, loss_dict, optimizer, optimizer_ds):
#     losses_avg = []
#     losses_cur = []
#     for key, loss in loss_dict.items():
#         losses_avg.append('{0}: {1} '.format(key, round(loss.avg, 5)))
#         # print('{0}: {1}'.format(key, round(loss.avg, 5)))
#         # f = open(os.path.join(cfg.logs, '{}.txt'.format(key)), mode='a')
#         # f.write('seed:{}, ite:{} :{}\n'.format(cfg.seed, ite, loss.avg))
#         # f.close()
#
#     losses_avg = ' /// '.join([loss for loss in losses_avg])
#     print('Loss avg iters: {0}/{1}'.format(ite, cfg.loops_train), Fore.GREEN + losses_avg, Style.RESET_ALL)
#
#     for _, loss in loss_dict.items():
#         loss.reset()
#
#     for param_group in optimizer.param_groups:
#         lr = param_group['lr']
#         print(optimizer.__class__.__name__, ' lr = %.8f' % lr)
#
#     for param_group in optimizer_ds.param_groups:
#         lr = param_group['lr']
#         print(optimizer.__class__.__name__, 'ds lr = %.8f' % lr)
#
#
# def test_workflow(cfg, model, ite, test_loader, writer=None, val_acc=None):
#     start_time = time.time()
#     print_key_params(cfg)
#
#     # print('*' * 15 + ' unseen domain:', Fore.MAGENTA + ' ///{0}/// '.format(test_domain) + Style.RESET_ALL, '*' * 15 )
#     # test(cfg=cfg, model=model, data_loader=val_loader, ite=ite, log_dir=cfg.logs, log_prefix='val')
#     with torch.no_grad():
#         acc = test(cfg=cfg, model=model, data_loader=test_loader, ite=ite, log_dir=cfg.logs, log_prefix='dg_test',
#                    writer=writer, val_acc=val_acc)
#
#     if writer is not None:
#         writer.add_scalar('ib/' + cfg.test_domain, round(acc * 100, 3), global_step=ite)
#     print('********* test time: {0}s ************'.format(time.time() - start_time))
#     return acc
#
#
# def test(cfg, model, data_loader, ite, log_prefix, log_dir='logs/', writer=None, val_acc=None):
#     # switch on the network test mode
#     model.eval()
#     preds_list = []
#     targets_list = []
#     num = 0
#     for i, (images, targets) in enumerate(data_loader):
#         num += images.size()[0]
#         images, labels = images.to(device), targets.to(device)
#         result = model(images)
#
#         predictions = result['Predictions'].cpu().data.numpy()
#         preds_list.extend(predictions)
#         # targets_list.extend(targets)
#         targets_list.extend(targets.cpu().data.numpy())
#
#         # if ite % cfg.print_freq == 0:
#         #     writer.add_image(
#         #                 'ib/test',
#         #                 torchvision.utils.make_grid(images.data[:6], 3, normalize=True), global_step=ite)
#
#     assert len(preds_list) == len(targets_list)
#     accuracy = compute_accuracy(predictions=preds_list, labels=targets_list)
#     head = Fore.MAGENTA if 'dg_test' in log_prefix else ''
#     tail = Style.RESET_ALL if 'dg_test' in log_prefix else ''
#     print(head, 'seed: {0}, lr: {1}'.format(cfg.seed, cfg.current_lr),
#           'image num: {0}'.format(num),
#           '------{prefix}------:{accuracy} ({domain} - {ite}/{loops} - val:{val_acc})'.format(
#               prefix=log_prefix, accuracy=round(accuracy * 100, 3), domain=cfg.test_domain,
#               ite=ite, loops=cfg.loops_train, val_acc=round(val_acc * 100, 3)), tail)
#
#     if not os.path.exists(log_dir):
#         os.makedirs(log_dir)
#
#     f = open(os.path.join(log_dir, '{}.txt'.format(log_prefix)), mode='a')
#     # f.write('unseen domain: ', self.test_domain)
#     f.write('seed:{}, ite:{}, accuracy:{}\n'.format(cfg.seed, ite, accuracy))
#     f.close()
#     return accuracy
#
#
# def print_key_params(cfg):
#     # print(Fore.RED + 'key params: seed: {0}, weight_decay: {1}, batch_size: {2}, '
#     #                  'shared_layer: {3}'.format(cfg.seed, cfg.weight_decay, cfg.batch_size, cfg.shared_layer),
#     #       Style.RESET_ALL)
#
#     infos = []
#     for key in sorted(set(cfg.keys()) ^ set(cfg.not_print_keys)):
#         val = cfg.__getitem__(key)
#         if hasattr(val, '__call__'):
#             continue
#         infos.append('{0}: {1}'.format(key, val))
#
#     print('params: ', Fore.RED + ", ".join(str(i) for i in infos) + Style.RESET_ALL)
#     print('sys args: ', cfg.sys_args)
#
#
# def val_workflow(cfg, model, val_loaders, ds_model):
#     # switch on the network test mode
#     model.eval()
#     ds_model.eval()
#     num = 0
#     ds_preds_list = {i: [[] for _ in range(len(val_loaders))] for i in range(len(cfg.train_domains))}
#     targets_list = [[] for _ in range(len(val_loaders))]
#     acc = []
#     print('=' * 30, 'valiation', '=' * 30)
#     for index, loader in enumerate(val_loaders):
#         main_pred = []
#
#         for i, (images, targets) in enumerate(loader):
#             num += images.size()[0]
#             images, labels = images.to(device), targets.to(device)
#
#             for domain in range(len(cfg.train_domains)):
#                 result = ds_model(images, domain_index=domain)
#                 predictions = result['Predictions'].cpu().data.numpy()
#                 ds_preds_list[domain][index].extend(predictions)
#
#             result = model(images)
#             predictions = result['Predictions'].cpu().data.numpy()
#             main_pred.extend(predictions)
#             targets_list[index].extend(targets.cpu().data.numpy())
#
#         accs = []
#         for i, d in enumerate(cfg.train_domains):
#             accuracy = compute_accuracy(predictions=ds_preds_list[i][index], labels=targets_list[index])
#             accs.append('{0}: {1}'.format(d, round(accuracy * 100, 3)))
#         accuracy_main = compute_accuracy(predictions=main_pred, labels=targets_list[index])
#         print('domain specific *{0}* val (img num: {1}) --| '.format(cfg.train_domains[index], len(loader.dataset)),
#               ' | '.join([acc for acc in accs]), ' ||| main: {0}'.format(round(accuracy_main * 100, 3)))
#         acc.append(accuracy_main)
#
#     val_acc = np.mean(acc)
#     print('=' * 30, 'main net val mean: {0}'.format(val_acc), '=' * 30)
#     return val_acc
#
#
# def compute_accuracy(predictions, labels):
#     if np.ndim(labels) == 2:
#         y_true = np.argmax(labels, axis=-1)
#     else:
#         y_true = labels
#     accuracy = accuracy_score(y_true=y_true, y_pred=np.argmax(predictions, axis=-1))
#     return accuracy
#
#
# def bn_eval(model, cfg):
#     if cfg.bn_eval_main:
#
#         for l in range(cfg.eval_layer_start, cfg.eval_layer_end):
#             module = model.main_net.__getattr__('layer{index}'.format(index=l))
#             for m in module:
#                 if isinstance(m, nn.BatchNorm2d):
#                     m.eval()
#                     m.weight.requires_grad = False
#                     m.bias.requires_grad = False
#
#
# def bn_eval_ds(model, cfg):
#     if cfg.bn_eval_ds:
#         for ds_net in model.ds_nets:
#             for m in ds_net.modules():
#                 if isinstance(m, nn.BatchNorm2d):
#                     m.eval()
#                     m.weight.requires_grad = False
#                     m.bias.requires_grad = False
#
#
# def load_checkpoint(cfg, net, load_path):
#     state_checkpoint = torch.load(load_path, map_location=lambda storage, loc: storage.cuda())
#     print('loading {0} ...'.format(load_path))
#     if os.path.isfile(load_path):
#
#         state_dict = net.state_dict()
#         # cfg.__setattr__('resume_ite', state_checkpoint['ite'])
#
#         ignore_list = list()
#         for k, v in state_checkpoint['state'].items():
#             k = str.replace(k, 'module.', '')
#             # print('loading: ', k)
#             if k in state_dict.keys() and v.size() == state_dict[k].size():
#                 state_dict[k] = v
#                 # print('loaded: ', k)
#             else:
#                 ignore_list.append(k)
#
#         print('fail loaded: ', ignore_list)
#         net.load_state_dict(state_dict)
#     else:
#         raise ValueError('No checkpoint found at {0}'.format(load_path))
#
#
# def get_scheduler(cfg, optimizer):
#     if cfg.scheduler == 'lambda_exp':
#
#         def lambda_rule(iters):
#             lr_l = (1 - float(iters) / cfg.loops_train) ** 0.9
#             lr_l = max(0.2, lr_l)
#             return lr_l
#
#         # def lambda_rule(iters):
#         #     lr_l = 1 - max(0, iters - 1400) / float(1600)
#         #     return lr_l
#
#         # def lambda_rule(epochs):
#         #     lr_scale = 1
#         #     if epochs < 15:
#         #         lr_scale = min(1., float(epochs + 1) / 15.)
#         #     return lr_scale
#
#         scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer=optimizer, lr_lambda=lambda_rule)
#     elif cfg.scheduler == 'lambda_linear':
#
#         def lambda_rule(iters):
#             lr_l = 1 - max(0, iters - cfg.loops_train * 0.8) / float(cfg.loops_train * 0.2)
#             return lr_l
#
#         scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer=optimizer, lr_lambda=lambda_rule)
#
#     elif cfg.scheduler == 'step':
#         scheduler = torch.optim.lr_scheduler.StepLR(optimizer=optimizer, step_size=cfg.loops_train * 2 // 3, gamma=0.5)
#     elif cfg.scheduler == 'multi_step':
#         scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer,
#                                                          milestones=[cfg.loops_train // 3, cfg.loops_train * 2 // 3],
#                                                          gamma=0.5)
#
#     return scheduler
#
#
# def split_integer(m, n):
#     assert n > 0
#     quotient = int(m / n)
#     remainder = m % n
#     if remainder > 0:
#         return [quotient] * (n - remainder) + [quotient + 1] * remainder
#     if remainder < 0:
#         return [quotient - 1] * -remainder + [quotient] * (n + remainder)
#     return [quotient] * n
#
# def add_imgs(writer, images, name, global_step):
#     writer.add_image(
#                 'ib/' + name,
#                 torchvision.utils.make_grid(images.data[:6], 3, normalize=True), global_step=global_step)
#
# def vis_cam(ite, cfg, model, result, images, paths, layer, index, index_cross, writer):
#     layer = 'layer' + str(layer)
#     feat_ori = result[layer][0]
#     feat_ds = result['ds_{0}_{1}'.format(str(index_cross[-1]), layer)][0]
#     feat_ib = result['ib_' + layer][0]
#
#     hmp_main_ori = feat_ori.sum(dim=0).detach().cpu().numpy()
#     hmp_main_ori = model._normalize(hmp_main_ori)
#     hmp_main_ori = cv2.resize(hmp_main_ori, (224, 224))
#     # hmp_main_ori = to_pil_image(activation_map, mode='F')
#
#     # ds act
#     hmp_ds = feat_ds.sum(dim=0).detach().cpu().numpy()
#     hmp_ds = model._normalize(hmp_ds)
#     hmp_ds = cv2.resize(hmp_ds, (224, 224))
#     # hmp_ds = to_pil_image(activation_map, mode='F')
#
#     # main ib
#     hmp_main_ib = feat_ib.sum(dim=0).detach().cpu().numpy()
#     hmp_main_ib = model._normalize(hmp_main_ib)
#     hmp_main_ib = cv2.resize(hmp_main_ib, (224, 224))
#
#     # img = io.imread(paths[0])
#     # img = np.float32(cv2.resize(img, (224, 224))) / 255
#
#     vis_image = images[0]
#     img = vis_image.cpu().numpy().transpose((1,2,0))
#
#     hmp_ds, _ = cam_util.gen_cam(img, hmp_ds)
#     # result['hmp_ds'] = overlay_mask(img, hmp_ds)
#     hmp_main_ori, _ = cam_util.gen_cam(img, hmp_main_ori)
#     hmp_main_ib, _ = cam_util.gen_cam(img, hmp_main_ib)
#
#
#     heat_cam = torch.cat(
#         [vis_image.cpu(), loader_img(hmp_main_ori), loader_img(hmp_ds), loader_img(hmp_main_ib)], 2)
#     writer.add_image(
#         'ib/cam_' + cfg.train_domains[index] + '_ds_{0}_actlayer_{1}'.format(cfg.train_domains[index_cross[0]],
#                                                                              cfg.ib_layers[0]),
#         torchvision.utils.make_grid(heat_cam.data, 3, normalize=True), global_step=ite + index)
#
# def get_gating_settings(cfg, index, index_list):
#
#     if -1 in cfg.ib_layers:
#         ib_layers = np.random.choice([1, 4], size=1)
#     else:
#         ib_layers = cfg.ib_layers
#
#     if 'a' in cfg.cross_domain:
#         index_cross = index_list
#     elif 'e' in cfg.cross_domain:  # exclude current index
#         index_cross = list(set([index]) ^ set(index_list))
#     else:
#         raise ValueError('cross domain indexes {} not supported'.format(cfg.cross_domain))
#
#     if 'random' == cfg.ib_interact:
#         ib_interact = np.random.choice(['single', 'intersect', 'unite'], size=1)
#     else:
#         ib_interact = cfg.ib_interact
#
#     if 'single' == ib_interact:
#         index_cross = np.random.choice(index_cross, size=1)
#
#     if cfg.ib_act_area == 'random':
#         act_area = np.random.choice(['similar', 'different'], size=1)[0]
#     else:
#         act_area = cfg.ib_act_area
#         if cfg.self_chlg and ib_interact == 'single' and index == index_cross[0]:
#             act_area = 'different'
#
#     if cfg.gated_strategy == 'random':
#         gated_strategy = np.random.choice(['channel', 'spatial'], size=1)[0]
#     else:
#         assert cfg.gated_strategy in ['channel', 'spatial', 'both']
#         gated_strategy = cfg.gated_strategy
#
#     return index_cross, gated_strategy, ib_interact, act_area, ib_layers
#
# if __name__ == "__main__":
#     torch.set_default_tensor_type('torch.cuda.FloatTensor')
#     main()
#
#

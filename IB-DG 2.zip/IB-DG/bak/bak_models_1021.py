# from functools import reduce
#
# import numpy as np
# import torch
# import torch.nn as nn
# import torch.nn.functional as F
# import torchvision
# import torchvision.models.vgg as vgg_models
# from torch.nn import init
# # from timm.models.resnet import resnet18, resnet50
# from torchvision.models.resnet import resnet18, resnet50
#
# from timm.models.alexnet import alexnet, alexnet_bn
# from timm.models.layers import SelectAdaptivePool2d
# import torch.nn.functional as F
# import random
# from collections import OrderedDict
# import os
#
# unloader_img = torchvision.transforms.ToPILImage(mode='RGB')
#
# def init_weights(net, init_type='normal', key='', gain=0.02):
#     print('initialize {key} with {type}'.format(key=key, type=init_type))
#
#     def init_func(m):
#         classname = m.__class__.__name__
#         if hasattr(m, 'weight') and m.weight is not None and m.weight.requires_grad:
#             if classname.find('Conv') != -1 or classname.find('Linear') != -1:
#                 if init_type == 'normal':
#                     init.normal_(m.weight.data, 0.0, gain)
#                 elif init_type == 'xavier':
#                     init.xavier_normal(m.weight.data, gain=gain)
#                 elif init_type == 'kaiming':
#                     init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
#                 elif init_type == 'orthogonal':
#                     init.orthogonal(m.weight.data, gain=gain)
#                 else:
#                     raise NotImplementedError('initialization method [%s] is not implemented' % init_type)
#                 if hasattr(m, 'bias') and m.bias is not None:
#                     init.constant_(m.bias.data, 0.0)
#             elif classname.find('BatchNorm2d') != -1:
#                 init.normal_(m.weight.data, 1.0, gain)
#                 init.constant_(m.bias.data, 0.0)
#
#     net.apply(init_func)
#
# def define_netowrks(cfg):
#     backbone = cfg.model
#     if 'resnet' in backbone:
#         model = Model_ResNet(cfg)
#
#     elif 'alexnet' in backbone:
#         model = Model_Alexnet(cfg)
#     # elif 'vgg' in backbone:
#     #     model = Model_Vgg(cfg)
#     else:
#         raise ValueError('model {0} is not defined'.format(backbone))
#
#     return model
#
# # class Model_DS(nn.Module):
# #
# #     def __init__(self, cfg):
# #         super(Model_DS, self).__init__()
# #         self.cfg = cfg
# #         if cfg.model == 'resnet':
# #             ds_net = Domain_Specific_ResNet(cfg)
# #         self.ds_nets = nn.ModuleList([ds_net for _ in range(3)])
# #
# #     def forward(self, x, index):
# #         return self.ds_nets[index](x)
#
# class DS_Model(nn.Module):
#
#     def __init__(self, cfg):
#         super(DS_Model, self).__init__()
#         self.cfg = cfg
#         # print(self.main_net)
#         if 'resnet' in cfg.ds_model:
#             self.ds_nets = nn.ModuleList([Domain_Specific_ResNet(cfg, cfg.ds_model, cfg.train_domains[i]) for i in range(3)])
#         elif 'alexnet' in cfg.ds_model:
#             self.ds_nets = nn.ModuleList([Domain_Specific_AlexNet(cfg, cfg.train_domains[i]) for i in range(3)])
#
#     def forward_ds(self, x, domain_index):
#         return self.ds_nets[domain_index](x)
#
#     def forward(self, x, domain_index):
#         return self.ds_nets[domain_index](x)
#
#     def clear_hooks(self):
#         """Clear model hooks"""
#         for ds in self.ds_nets:
#             ds.hook_feats_in.clear()
#             ds.hook_feats_out.clear()
#             ds.hook_grads_in.clear()
#             ds.hook_grads_out.clear()
#             ds.hook_fc_out.clear()
#             ds.hook_fc_grads_out.clear()
#             ds.hook_modules.clear()
#             ds.gradients.clear()
#             for h in ds.hook_handlers:
#                 h.remove()
#
#
# class Model_ResNet(nn.Module):
#
#     def __init__(self, cfg):
#         super(Model_ResNet, self).__init__()
#         self.cfg = cfg
#         self.main_net = Domain_Specific_ResNet(cfg, cfg.model)
#         # print(self.main_net)
#         self.layers = ['layer1', 'layer2', 'layer3', 'layer4']
#         self.block = DropBlock2D(0.5, 5)
#
#         self.global_pool = nn.AdaptiveAvgPool2d(1)
#         # self.ds_nets = nn.ModuleList([Domain_Specific_ResNet(cfg, cfg.ds_model, cfg.train_domains[i]) for i in range(3)])
#
#     def unfix_grad(self, net):
#         def fix_func(m):
#             classname = m.__class__.__name__
#             if classname.find('Conv') != -1 or classname.find('BatchNorm2d') != -1 or classname.find('Linear') != -1:
#                 m.weight.requires_grad = True
#                 if m.bias is not None:
#                     m.bias.requires_grad = True
#
#         net.apply(fix_func)
#
#     def fix_grad(self, net):
#         # print(net.__class__.__name__)
#
#         def fix_func(m):
#             classname = m.__class__.__name__
#             if classname.find('Conv') != -1 or classname.find('BatchNorm2d') != -1:
#                 m.weight.requires_grad = False
#                 if m.bias is not None:
#                     m.bias.requires_grad = False
#
#         net.apply(fix_func)
#
#     def change_dropout(self, net, rate):
#         # print(net.__class__.__name__)
#
#         def change_rate(m):
#             classname = m.__class__.__name__
#             if classname.find('Dropout') != -1:
#                 m.p = rate
#
#         net.apply(change_rate)
#
#     def load_weights(self, net_source, net_target):
#         state_dict = net_source.state_dict()
#         for k, v in net_target.state_dict().items():
#             if k in state_dict.keys() and v.size() == state_dict[k].size():
#                 state_dict[k] = v
#             else:
#                 print('not loaded ib module: ', k)
#         net_source.load_state_dict(state_dict)
#
#     def get_1x_lr_params(self):
#         params_1x = {n:p for n, p in self.named_parameters() if 'fc' not in n and p.requires_grad}
#         # print('params_1x ', params_1x.keys())
#         return list(params_1x.values())
#
#     def get_10x_lr_params(self):
#         params_10x = {n:p for n, p in self.named_parameters() if 'fc' in n and p.requires_grad}
#         # print('params_10x ', params_10x.keys())
#         return list(params_10x.values())
#
#     def ib_act(self, ds_feats, source, act_area=None, ignore_index=None):
#
#         zeros_t = torch.zeros_like(source)
#         ones_t = torch.ones_like(source)
#
#         if self.cfg.ib_interact == 'random':
#             interact = np.random.choice(['unite', 'intersect'], size=1)[0]
#         else:
#             interact = self.cfg.ib_interact
#
#         if interact == 'single' or interact =='test':
#             cross_d_act = ds_feats[0]
#         elif interact == 'unite':
#             cross_d_act = sum(ds_feats)
#         elif interact == 'intersect':
#             cross_d_act = reduce(lambda x, y: x * y, ds_feats)
#         else:
#             raise ValueError('ambiguous action {0} on ib interaction!'.format(self.cfg.ib_interact))
#
#         if act_area == 'similar':
#             mask = torch.where(cross_d_act > 0, ones_t, zeros_t)
#         elif act_area == 'different':
#             mask = torch.where(cross_d_act > 0, zeros_t, ones_t)
#         else:
#             raise ValueError('ib area {0} not supported!!!'.format(act_area))
#
#         # out = self.block(source)
#
#         # input_num = source.size()[0]
#         # indexes_all = [i for i in range(input_num)]
#         # keep_index = random.sample(indexes_all, int(input_num * (1 - self.cfg.ib_rate)))
#         # mask[keep_index] = ones_t[keep_index]
#
#         if self.cfg.mix_ib:
#             # input_num = source.size()[0]
#             # ib_num = int(input_num * self.cfg.ib_rate)
#             # ib_num = int(input_num * (1 - self.cfg.ib_rate))
#             # mask[:ib_num, ] = ones_t[:ib_num, ]
#             mask[ignore_index, ] = ones_t[ignore_index, ]
#
#         assert mask.size() == source.size()
#         gated = source * mask
#
#         ib_rate = len(torch.nonzero(gated, as_tuple=True)[0]) / len(
#            torch.nonzero(source, as_tuple=True)[0])
#         if ib_rate == 0 or ib_rate == 1:
#             return source
#
#         if gated.ndim == 2:
#             return gated
#
#         source_count = torch.where(source > 0, ones_t, zeros_t).sum(dim=(1,2,3))
#         gated_count = torch.where(gated > 0, ones_t, zeros_t).sum(dim=(1, 2, 3))
#         scale = torch.where(gated_count > 0, source_count / gated_count, torch.ones_like(gated_count))
#
#         # count_all = torch.where(source > 0, ones_t, zeros_t).sum(dim=(1,2,3)) / torch.where(gated > 0, ones_t, zeros_t).sum(dim=(1,2,3))
#         # source_count = torch.where(source > 0, ones_t, zeros_t).sum(dim=(2, 3))
#         # gated_count = torch.where(gated > 0, ones_t, zeros_t).sum(dim=(2, 3))
#         # scale = torch.where(gated_count > 0, source_count / gated_count, torch.ones_like(gated_count))
#         # scale = torch.where(scale > count_all, torch.ones_like(scale) * count_all, scale)
#         # return gated * scale.unsqueeze(-1).unsqueeze(-1)
#
#         # if self.cfg.mix_ib:
#         #     input_num = source.size()[0]
#         #     index_all = np.array(range(input_num))
#         #     magnify_index = np.setdiff1d(index_all, ignore_index)
#         #     gated[magnify_index] = gated[magnify_index] * count_all
#         # else:
#         #     gated = gated * count_all
#         # return gated * scale.unsqueeze(-1).unsqueeze(-1)
#         gated = gated * scale.unsqueeze(-1).unsqueeze(-1).unsqueeze(-1)
#
#         if self.cfg.mix_ib:
#             gated[ignore_index] = source[ignore_index]
#             input_num = source.size()[0]
#             ib_index = list(set(range(input_num)) ^ set(ignore_index))
#             unchange_number = int(len(ib_index) * (1-self.cfg.ib_rate))
#             unchange_index = np.random.choice(ib_index, size=unchange_number, replace=False)
#             gated[unchange_index] = source[unchange_index]
#             # unchange_number = int(input_num * (1-self.cfg.ib_rate)) - len(ignore_index)
#             # if unchange_number > 0:
#             #     unchange_index = np.random.choice(list(set(range(input_num)) ^ set(ignore_index)), size=unchange_number, replace=False)
#             #     gated[unchange_index] = source[unchange_index]
#
#
#         return gated
#
#     def forward_ds(self, x, domain_index):
#         return self.ds_nets[domain_index](x)
#
#     def forward_ds_higher(self, x, domain_index, skip_first_pool=False):
#         return self.ds_nets[domain_index].forward_higher(x, skip_first_pool=skip_first_pool)
#
#     def forward(self, x, dropout=False):
#         if self.cfg.ib_fc_layers[0] >= 0 and 'alexnet' in self.cfg.model:
#             for i in self.cfg.ib_fc_layers:
#                 self.main_net.fc[i + 2].p = self.cfg.p
#         return self.main_net(x, dropout=dropout)
#
#     def _get_crossdomain_act(self, hook_a, hook_g, gate_strategy='channel'):
#         # assert hook_g.ndim in [2, 4]
#         assert hook_a.size() == hook_g.size()
#         if hook_g.ndim == 2:
#             weights = hook_g.detach()
#             return F.relu(weights * hook_a.detach(), inplace=True)
#         if gate_strategy == 'direct':
#             weights = hook_g.detach().mean(axis=(2, 3))
#             return hook_a.detach() * weights.unsqueeze(-1).unsqueeze(-1)
#         elif gate_strategy == 'channel':
#             weights = hook_g.detach().mean(axis=(2, 3))
#             return F.relu(hook_a.detach() * weights.unsqueeze(-1).unsqueeze(-1), inplace=True)
#         elif gate_strategy == 'spatial':
#             # spatial
#             weights = torch.mean(hook_g.detach(), dim=1, keepdim=True)
#             return F.relu(hook_a.detach() * weights, inplace=True)
#         elif gate_strategy == 'both':
#             weights_c = hook_g.detach().mean(axis=(2, 3)).unsqueeze(-1).unsqueeze(-1)
#             weights_s = torch.mean(hook_g.detach(), dim=1, keepdim=True)
#             return F.relu(hook_a.detach() * weights_c * weights_s, inplace=True)
#         elif gate_strategy == 'pp':
#             grad_2 = hook_g.pow(2)
#             grad_3 = hook_g.pow(3)
#             alpha = grad_2 / (2 * grad_2 + (grad_3 * hook_a).sum(axis=(2, 3), keepdims=True))
#             weights = alpha.squeeze_(0).mul_(torch.relu(hook_g.squeeze(0)))
#             return F.relu(hook_a.detach() * weights, inplace=True)
#
#     # def forward_ib_grad_a(self, x, index_cross, labels, act_area, ib_layers=None, ds_model=None,
#     #                       gate_strategy='channel', current_index=None):
#     #
#     #     result = {}
#     #
#     #     act_ds = []
#     #     act_main_ori = []
#     #     act_main_ib = []
#     #     index = index_cross[0]
#     #     # self.main_net._hook_layers(ib_layers, grad=False)
#     #
#     #     for l in range(0, 7):
#     #
#     #         if l in self.main_net.maxpool_layers:
#     #             x = self.main_net.maxpool(x)
#     #
#     #         if l in ib_layers:
#     #
#     #             # hook_a_main = self.main_net.hook_feats_in[0][0]
#     #
#     #             ds_net = ds_model.ds_nets[index]
#     #             ds_net._hook_layers([l])
#     #             ds_net.eval()
#     #
#     #             ds_result = ds_net.forward_higher(x.detach().requires_grad_(), l, skip_first_pool=True)
#     #             ds_net.backprop(ds_result['cls'], labels)
#     #
#     #             hook_a = ds_net.hook_feats_out[0]
#     #             hook_g = ds_net.hook_grads_out[-1]
#     #
#     #             # if self.cfg.mask == 'ds':
#     #             # act = hook_a
#     #             # elif self.cfg.mask == 'main':
#     #             #     act = self.main_net.hook_feats_out[0]
#     #             # elif self.cfg.mask == 'bug':
#     #             #     act = hook_a[0]
#     #
#     #             act_ds.append(self._get_crossdomain_act(hook_a, hook_g, gate_strategy=gate_strategy))
#     #             del ds_net.hook_feats_out[0]
#     #             del ds_net.hook_grads_out[-1]
#     #             ds_model.clear_hooks()
#     #
#     #             self.main_net.hook_feats_in = []
#     #             self.main_net.hook_feats_out = []
#     #
#     #         if l < 5:
#     #             layer = 'layer{index}'.format(index=l)
#     #             x = self.main_net.__getattr__(layer)(x)
#     #             result[layer] = x
#     #         elif l == 5:
#     #             x = self.main_net.global_pool(x)
#     #         else:
#     #             x = self.main_net.fc(x.flatten(1))
#     #
#     #         if l in ib_layers:
#     #             act_main_ori.append(x.detach())
#     #             x = self.ib_act(act_ds, x, act_area)
#     #             act_main_ib.append(x.detach())
#     #             act_ds = []
#     #
#     #         if l < 6:
#     #             result['feat'] = x
#     #         else:
#     #             result['cls'] = x
#     #
#     #     self.main_net.clear_hooks()
#     #     result.update(self._cal_ib_preserve_rate(act_main_ori, act_main_ib, ib_layers))
#     #     return result
#
#     def forward_ib_grad_a(self, x, index_cross, labels, act_area, ib_layers=None, ds_model=None, gate_strategy='channel', current_index=None, list_domains=None):
#
#         if self.cfg.ib_fc_layers[0] >= 0 and 'alexnet' in self.cfg.model:
#             for i in self.cfg.ib_fc_layers:
#                 self.main_net.fc[i + 2].p = 0
#
#         if self.cfg.gate_pos == 'img':
#             result = {}
#             for index in index_cross:
#                 ds_net = ds_model.ds_nets[index]
#                 ds_net.eval()
#                 if ib_layers is None:
#                     ib_layers = self.cfg.ib_layers
#                 ds_net._hook_layers(ib_layers, gate_level=self.cfg.gate_level)
#                 ds_result = ds_net(x)
#                 ds_net.backprop(ds_result['cls'], labels)
#
#             # act_ds = []
#             act_main_ori = []
#             act_main_ib = []
#
#             if self.cfg.mask == 'main':
#                 self.main_net._hook_layers(ib_layers, grad=False)
#
#             for l in range(0, 7):
#
#                 if l in self.main_net.maxpool_layers:
#                     x = self.main_net.maxpool(x)
#
#                 if l < 5:
#                     layer = 'layer{index}'.format(index=l)
#                     x = self.main_net.__getattr__(layer)(x)
#                     result[layer] = x
#                 else:
#                     x = self.main_net.global_pool(x)
#                     x = self.main_net.fc(x.flatten(1))
#
#                 if l in ib_layers:
#                     act_ds = []
#                     for index in index_cross:
#                         ds_net = ds_model.ds_nets[index]
#                         hook_a = ds_net.hook_feats_out[0]
#                         hook_g = ds_net.hook_grads_out[-1]
#                         # hook_a = ds_net.hook_feats_in[0]
#                         assert x.size() == hook_g.size()
#                         assert hook_a.size() == hook_g.size()
#                         if self.cfg.mask == 'ds':
#                             act = hook_a
#                         elif self.cfg.mask == 'main':
#                             act = self.main_net.hook_feats_out[0]
#                         elif self.cfg.mask == 'bug':
#                             act = hook_a[0]
#
#                         guided_act = self._get_crossdomain_act(act, hook_g, gate_strategy=gate_strategy)
#                         result['ds_{}_{}'.format(str(index), layer)] = guided_act
#
#                         act_ds.append(guided_act)
#                         # del ds_net.hook_feats_in[0]
#                         ds_net.hook_feats_out.pop(0)
#                         ds_net.hook_grads_out.pop(-1)
#                         if self.main_net.hook_feats_out:
#                             self.main_net.hook_feats_out.pop(0)
#
#                     act_main_ori.append(x.detach())
#                     if self.cfg.self_chlg and self.cfg.ib_interact == 'single' and current_index == index_cross[0]:
#                         act_area = 'different'
#
#                     x = self.ib_act(act_ds, x, act_area)
#                     # x[ib_index] = self.ib_act(act_ds, x, act_area)[ib_index]
#                     act_main_ib.append(x.detach())
#
#                     result['ib_' + layer] = x
#
#                 if l < 5:
#                     result['feat'] = x
#                 else:
#                     result['cls'] = x
#
#             ds_model.clear_hooks()
#             self.clear_hooks()
#             result.update(self._cal_ib_preserve_rate(act_main_ori, act_main_ib, ib_layers))
#             return result
#
#         elif self.cfg.gate_pos == 'feat0':
#             result = {}
#             for index in index_cross:
#                 ds_net = ds_model.ds_nets[index]
#                 ds_net.eval()
#                 if ib_layers is None:
#                     ib_layers = self.cfg.ib_layers
#                 ds_net._hook_layers(ib_layers, gate_level=self.cfg.gate_level)
#                 ds_input = self.main_net.layer0(x)
#                 ds_result = ds_net.forward_higher(ds_input, 1)
#                 # ds_result = ds_net(x)
#                 ds_net.backprop(ds_result['cls'], labels)
#
#             # act_ds = []
#             act_main_ori = []
#             act_main_ib = []
#
#             for l in range(0, 6):
#
#                 if l in self.main_net.maxpool_layers:
#                     x = self.main_net.maxpool(x)
#
#                 if l < 5:
#                     layer = 'layer{index}'.format(index=l)
#                     x = self.main_net.__getattr__(layer)(x)
#                     result[layer] = x
#                 else:
#                     x = self.main_net.global_pool(x)
#                     x = self.main_net.fc(x.flatten(1))
#
#                 if l in ib_layers:
#                     act_ds = []
#                     for index in index_cross:
#                         ds_net = ds_model.ds_nets[index]
#                         hook_a = ds_net.hook_feats_out[0]
#                         hook_g = ds_net.hook_grads_out[-1]
#                         # hook_a = ds_net.hook_feats_in[0]
#                         assert x.size() == hook_g.size()
#                         assert hook_a.size() == hook_g.size()
#                         # if self.cfg.mask == 'ds':
#                         act = hook_a
#                         # elif self.cfg.mask == 'main':
#                         #     act = self.main_net.hook_feats_out[0]
#                         # elif self.cfg.mask == 'bug':
#                         #     act = hook_a[0]
#
#                         guided_act = self._get_crossdomain_act(act, hook_g, gate_strategy=gate_strategy)
#                         result['ds_{}_{}'.format(str(index), layer)] = guided_act
#
#                         act_ds.append(guided_act)
#                         # del ds_net.hook_feats_in[0]
#                         ds_net.hook_feats_out.pop(0)
#                         ds_net.hook_grads_out.pop(-1)
#                         if self.main_net.hook_feats_out:
#                             self.main_net.hook_feats_out.pop(0)
#
#                     act_main_ori.append(x.detach())
#                     if self.cfg.self_chlg and self.cfg.ib_interact == 'single' and current_index == index_cross[0]:
#                         act_area = 'different'
#
#                     x = self.ib_act(act_ds, x, act_area)
#                     # x[ib_index] = self.ib_act(act_ds, x, act_area)[ib_index]
#                     act_main_ib.append(x.detach())
#
#                     result['ib_' + layer] = x
#
#                 if l < 5:
#                     result['feat'] = x
#                 else:
#                     result['cls'] = x
#
#             ds_model.clear_hooks()
#             self.clear_hooks()
#             result.update(self._cal_ib_preserve_rate(act_main_ori, act_main_ib, ib_layers))
#             return result
#
#         elif self.cfg.gate_pos == 'hook_f':
#             # assert
#             result = {}
#             act_ds = []
#             act_main_ori = []
#             act_main_ib = []
#             index = index_cross[0]
#
#             for l in range(0, 6):
#
#                 if l in self.main_net.maxpool_layers:
#                     x = self.main_net.maxpool(x)
#                 layer = 'layer{index}'.format(index=l)
#                 if l not in ib_layers:
#                     if l < 5:
#                         x = self.main_net.__getattr__(layer)(x)
#                         if l in self.cfg.detach_layers:
#                             x = x.detach()
#                         result[layer] = x
#                     else:
#                         x = self.main_net.global_pool(x).flatten(1)
#                         x = self.main_net.fc(x)
#                         result['cls'] = x
#                     if l < 5:
#                         result['feat'] = x
#                     continue
#
#                 ignore_index = np.where(list_domains == index)[0]
#                 if self.cfg.gate_level == 'pixel' and 'resnet' in self.cfg.model:
#                     if l == 0:
#                         x = self.main_net.__getattr__(layer)(x)
#                     elif l < 5:
#                         m = self.main_net.__getattr__(layer)._modules
#                         num_blocks = len(m)
#                         for i, (k, block) in enumerate(m.items()):
#                             if i != num_blocks - 1:
#                                 x = block(x)
#                                 result[layer] = x
#                             else:
#                                 identity = x
#                                 out = block.conv1(x)
#                                 out = block.bn1(out)
#                                 out = block.relu(out)
#                                 out = block.conv2(out)
#                                 _hook_x = out
#                                 out = block.bn2(out)
#                                 if 'resnet50' in self.cfg.model:
#                                     out = block.conv3(out)
#                                     _hook_x = out
#                                     out = block.bn3(out)
#                                 if block.downsample is not None:
#                                     identity = block.downsample(x)
#                                 out += identity
#                                 x = block.relu(out)
#                                 result[layer] = x
#
#                                 ds_net = ds_model.ds_nets[index]
#                                 ds_net.eval()
#                                 z = _hook_x.detach().requires_grad_()
#                                 z.register_hook(ds_net.save_gradient)
#
#                                 if self.cfg.bp == 'ds':
#                                     ds_result = ds_net.forward_higher(nn.ReLU()(z), l + 1, skip_first_pool=True)
#                                     ds_net.backprop(ds_result['cls'], labels)
#                                 else:
#                                     assert l in [0, 1, 2, 3]
#                                     ds_result = ds_net.forward_features(nn.ReLU()(z), l + 1, skip_first_pool=True)
#                                     cls = self.main_net.forward_fc(ds_result['feat'])
#                                     ds_net.backprop(cls, labels)
#
#                                 hook_g = ds_net.gradients[-1].clone().detach()
#                                 guided_act = self._get_crossdomain_act(z, hook_g, gate_strategy=gate_strategy)
#                                 result['ds_{}_{}'.format(str(index), layer)] = guided_act
#                                 act_ds.append(guided_act)
#                                 del ds_net.gradients[-1]
#
#                                 act_main_ori.append(x.detach())
#
#                                 x = self.ib_act(act_ds, x, act_area, ignore_index)
#                                 act_main_ib.append(x.detach())
#                                 result['ib_' + layer] = x
#                                 act_ds = []
#                 else:
#                     if l < 5:
#                         x = self.main_net.__getattr__(layer)(x)
#                         result[layer] = x
#
#                         ds_net = ds_model.ds_nets[index]
#                         ds_net.eval()
#
#                         z = x.detach().requires_grad_()
#                         z.register_hook(ds_net.save_gradient)
#                         if self.cfg.bp == 'ds':
#                             ds_result = ds_net.forward_higher(z, l + 1, skip_first_pool=True)
#                             ds_net.backprop(ds_result['cls'], labels)
#                         else:
#                             assert l in [0, 1, 2, 3]
#                             ds_result = ds_net.forward_features(z, l + 1, skip_first_pool=True)
#                             cls = self.main_net.forward_fc(ds_result['feat'])
#                             ds_net.backprop(cls, labels)
#
#                         hook_g = ds_net.gradients[-1].clone().detach()
#                         act_ds.append(self._get_crossdomain_act(z, hook_g, gate_strategy=gate_strategy))
#                         del ds_net.gradients[-1]
#
#                         act_main_ori.append(x.detach())
#                         x = self.ib_act(act_ds, x, act_area, ignore_index=ignore_index)
#                         act_main_ib.append(x.detach())
#
#                         if l in self.cfg.detach_layers:
#                             x = x.detach()
#
#                         act_ds = []
#
#             result.update(self._cal_ib_preserve_rate(act_main_ori, act_main_ib, ib_layers))
#             return result
#
#         elif self.cfg.gate_pos == 'hook_m':
#             result = {}
#
#             act_ds = []
#             act_main_ori = []
#             act_main_ib = []
#             index = index_cross[0]
#
#             for l in range(0, 6):
#
#                 if l in self.main_net.maxpool_layers:
#                     x = self.main_net.maxpool(x)
#
#                 if l in ib_layers:
#
#                     ds_net = ds_model.ds_nets[index]
#                     ds_net._hook_layers([l])
#                     ds_net.eval()
#
#                     if self.cfg.bp == 'ds':
#                         ds_result = ds_net.forward_higher(x.detach().requires_grad_(), l, skip_first_pool=True)
#                         ds_net.backprop(ds_result['cls'], labels)
#                     else:
#                         ds_result = ds_net.forward_features(x.detach().requires_grad_(), l, skip_first_pool=True)
#                         cls = self.main_net.forward_fc(ds_result['feat'])
#                         ds_net.backprop(cls, labels)
#
#                     hook_a = ds_net.hook_feats_out[0]
#                     hook_g = ds_net.hook_grads_out[-1]
#
#                     act_ds.append(self._get_crossdomain_act(hook_a, hook_g, gate_strategy=gate_strategy))
#                     del ds_net.hook_feats_out[0]
#                     del ds_net.hook_grads_out[-1]
#
#                     self.main_net.hook_feats_in = []
#                     self.main_net.hook_feats_out = []
#
#                 if l < 5:
#                     if l in self.cfg.detach_layers:
#                         x = x.detach()
#                     layer = 'layer{index}'.format(index=l)
#                     x = self.main_net.__getattr__(layer)(x)
#                     result[layer] = x
#
#                     if l in ib_layers:
#                         act_main_ori.append(x.detach())
#                         x = self.ib_act(act_ds, x, act_area)
#                         act_main_ib.append(x.detach())
#                         act_ds = []
#
#                 else:
#                     x = self.main_net.global_pool(x).flatten(1)
#                     if self.cfg.ib_fc_layers[0] >= 0:
#                         x = self.forward_ib_fc(x, index_cross, act_main_ori, act_main_ib, act_area, ds_model, gate_strategy)
#                     else:
#                         x = self.main_net.forward_fc(x.flatten(1))
#                     # x = self.main_net.fc(x.flatten(1))
#
#                 if l < 5:
#                     result['feat'] = x
#                 else:
#                     result['cls'] = x
#
#             ds_model.clear_hooks()
#             self.main_net.clear_hooks()
#             result.update(self._cal_ib_preserve_rate(act_main_ori, act_main_ib, ib_layers))
#             return result
#         else:
#             raise ValueError('unsupported gate position found {0}'.format(self.cfg.gate_pos))
#
#     def forward_ib_fc(self, x, index_cross, act_main_ori, act_main_ib, act_area, ds_model, gate_strategy):
#
#         if isinstance(self.main_net.fc, nn.Linear):
#             x = self.main_net.fc(x)
#             act_ds = []
#             for index in index_cross:
#                 ds_net = ds_model.ds_nets[index]
#                 hook_a = ds_net.hook_fc_out[0]
#                 hook_g = ds_net.hook_fc_grads_out[-1]
#                 act_ds.append(self._get_crossdomain_act(hook_a, hook_g, gate_strategy))
#                 del ds_net.hook_fc_out[0]
#                 del ds_net.hook_fc_grads_out[-1]
#
#             act_main_ori.append(x.detach())
#             x = self.ib_act(act_ds, x, act_area)
#             act_main_ib.append(x.detach())
#         else:
#             for l in range(0, len(self.main_net.fc)):
#                 x = self.main_net.fc[l](x)
#                 if l in self.cfg.ib_fc_layers:
#                     act_ds = []
#                     for index in index_cross:
#                         ds_net = ds_model.ds_nets[index]
#                         hook_a = ds_net.hook_fc_out[0]
#                         hook_g = ds_net.hook_fc_grads_out[-1]
#                         act_ds.append(self._get_crossdomain_act(hook_a, hook_g, gate_strategy))
#                         del ds_net.hook_fc_out[0]
#                         del ds_net.hook_fc_grads_out[-1]
#
#                     act_main_ori.append(x.detach())
#                     x = self.ib_act(act_ds, x, act_area)
#                     act_main_ib.append(x.detach())
#
#         return x
#
#     def set_requires_grad(self, net, requires_grad=False):
#
#         for name, param in net.named_parameters():
#             param.requires_grad = requires_grad
#
#     def _cal_ib_preserve_rate(self, feat_ori_list, feat_ib_list, ib_layers):
#         result = {}
#         for i, l in enumerate(ib_layers):
#             l = 'layer' + str(l)
#             feat_ori = feat_ori_list.pop()
#             feat_ib = feat_ib_list.pop()
#             try:
#                 ib_rate = len(torch.nonzero(feat_ib, as_tuple=True)[0]) / len(
#                     torch.nonzero(feat_ori, as_tuple=True)[0])
#
#             except ZeroDivisionError:
#                 raise ValueError('{0} is all zeros, can not be divided.'.format(l))
#             result['ib_preserve_rate_' + l] = ib_rate
#
#         for l_fc in self.cfg.ib_fc_layers:
#             if l_fc < 0:
#                 continue
#             l = 'fc' + str(l_fc)
#             feat_ori = feat_ori_list.pop()
#             feat_ib = feat_ib_list.pop()
#             try:
#                 ib_rate = len(torch.nonzero(feat_ib, as_tuple=True)[0]) / len(
#                     torch.nonzero(feat_ori, as_tuple=True)[0])
#
#             except ZeroDivisionError:
#                 raise ValueError('{0} is all zeros, can not be divided.'.format(l))
#             result['ib_preserve_rate_' + l] = ib_rate
#
#         # if ib_fc_layers[0] > -1:
#         #
#         #     offset = 0 if ib_layers[0] > 4 else len(ib_layers)
#         #
#         #     for i, l in enumerate(ib_fc_layers):
#         #         l = 'fc.' + str(l)
#         #         feat_ori = feat_ori_list[i + offset]
#         #         feat_ib = feat_ib_list[i + offset]
#         #         try:
#         #             ib_rate = len(torch.nonzero(feat_ib, as_tuple=True)[0]) / len(
#         #                 torch.nonzero(feat_ori, as_tuple=True)[0])
#         #
#         #         except ZeroDivisionError:
#         #             raise ValueError('{0} is all zeros, can not be divided.'.format(l))
#         #         result['ib_preserve_rate_' + l] = ib_rate
#         return result
#
#     def clear_hooks(self):
#         """Clear model hooks"""
#         self.main_net.hook_feats_in.clear()
#         self.main_net.hook_feats_out.clear()
#         self.main_net.hook_grads_in.clear()
#         self.main_net.hook_grads_out.clear()
#         self.main_net.hook_fc_out.clear()
#         self.main_net.hook_fc_grads_out.clear()
#         self.main_net.gradients.clear()
#         for h in self.main_net.hook_handlers:
#             h.remove()
#
#
#     @staticmethod
#     def _normalize(cam):
#
#         cam -= np.min(cam)
#         cam /= np.max(cam)
#
#         return cam
#     # def _normalize(cams):
#     #     """CAM normalization"""
#     #     cams -= cams.flatten(start_dim=-2).min(-1).values.unsqueeze(-1).unsqueeze(-1)
#     #     cams /= cams.flatten(start_dim=-2).max(-1).values.unsqueeze(-1).unsqueeze(-1)
#     #
#     #     return cams
#
#
# class Model_Alexnet(Model_ResNet):
#
#     def __init__(self, cfg):
#         super(Model_Alexnet, self).__init__(cfg)
#
#         self.cfg = cfg
#         self.main_net = Domain_Specific_AlexNet(cfg)
#         # init_weights(self.main_net.fc, 'normal')
#         # if cfg.ib_fc_layers[0] >= 0:
#         #     self.main_net.fc[0].p = 0
#         #     self.main_net.fc[3].p = 0
#
#         # self.ds_nets = nn.ModuleList([Domain_Specific_AlexNet(cfg) for _ in range(3)])
#         # for ds_net in self.ds_nets:
#         #     ds_net.fc = nn.Linear(256, cfg.num_classes)
#
#         self.hook_feats_out = []
#         self.hook_grads_out = []
#         self.hook_handlers = []
#         self.gradients = []
#
#         # init_weights(self.main_net.fc[6])
#
#     # def forward_ds(self, x, domain_index):
#     #     result = {}
#     #     ds_net = self.ds_nets[domain_index]
#     #     x = ds_net.forward_features(x)
#     #     x = ds_net.global_pool(x['feat']).flatten(1)
#     #     x = ds_net.fc(x)
#     #     result['cls'] = x
#     #     result['Predictions'] = F.softmax(input=x, dim=-1)
#     #     return result
#
#
# # class Model_Vgg(Model_ResNet):
# #
# #     def __init__(self, cfg):
# #         super(Model_Vgg, self).__init__(cfg)
# #
# #         self.cfg = cfg
# #         self.main_net = Domain_Specific_VGG(cfg)
# #         # init_weights(self.main_net.fc, 'normal')
# #         if cfg.ib_fc_layers[0] >= 0:
# #             self.main_net.fc[0].p = 0
# #             self.main_net.fc[3].p = 0
# #
# #         self.ds_nets = nn.ModuleList([Domain_Specific_VGG(cfg) for _ in range(3)])
# #         # for ds_net in self.ds_nets:
# #         #     ds_net.fc = nn.Linear(256, cfg.num_classes)
# #
# #         self.hook_feats_out = []
# #         self.hook_grads_out = []
# #         self.hook_handlers = []
# #         self.gradients = []
# #
# #         # init_weights(self.main_net.fc[6])
# #
# #     def forward(self, x):
# #         result = self.main_net.forward(x)
# #         return result
# #
# #     def forward_ds(self, x, domain_index):
# #         result = {}
# #         ds_net = self.ds_nets[domain_index]
# #         x = ds_net.forward_features(x)
# #         x = ds_net.global_pool(x['feat']).flatten(1)
# #         x = ds_net.fc(x)
# #         result['cls'] = x
# #         result['Predictions'] = F.softmax(input=x, dim=-1)
# #         return result
#
# class Base_Domain_Specific_Network(nn.Module):
#
#     def __init__(self, cfg):
#         super(Base_Domain_Specific_Network, self).__init__()
#
#         self.cfg = cfg
#         self.hook_feats_in = []
#         self.hook_feats_out = []
#         self.hook_grads_in = []
#         self.hook_grads_out = []
#         self.hook_fc_out = []
#         self.hook_fc_grads_out = []
#         self.hook_handlers = []
#         self.hook_modules = []
#         self.gradients = []
#         self.ce_loss = nn.CrossEntropyLoss()
#
#         # if 'dropout' in cfg.model:
#         #     for l in cfg.ib_layers:
#         #         assert l in list(np.range(7))
#         #         if l < 5:
#         #             layer = 'layer' + str(l)
#         #         elif l == 5:
#         #             layer = 'global_pool'
#         #         else:
#         #             layer = 'fc'
#         #         self.__setattr__(layer, nn.Sequential(self.__getattr__(layer), nn.Dropout2d(cfg.ib_rate)))
#
#     def forward(self, x, dropout=False):
#
#         result = self.forward_features(x, dropout=dropout)
#         cls = self.forward_fc(result['feat'])
#         result['cls'] = cls
#         result['Predictions'] = F.softmax(input=cls, dim=-1)
#         return result
#
#     def forward_features(self, x, start_index=0, return_layer=None, skip_first_pool=False, dropout=False):
#         result = {}
#         if 'alexnet_caffe' == self.cfg.model and start_index == 0:
#             x = x * 57.6
#         for l in range(start_index, 4 + 1):
#             if l in self.maxpool_layers and not (skip_first_pool and l == start_index):
#                 x = self.maxpool(x)
#             layer = 'layer{index}'.format(index=l)
#             x = self.__getattr__(layer)(x)
#             if dropout and l in self.cfg.ib_layers:
#                 x = F.dropout2d(x, p=self.cfg.drop_rate)
#             result[layer] = x
#             if return_layer is not None and l == return_layer:
#                 result['feat'] = x
#                 return result
#         x = self.global_pool(x)
#         # if dropout and 5 in self.cfg.ib_layers:
#         #     x = F.dropout2d(x, p=self.cfg.ib_rate)
#         result['feat'] = x
#         return result
#
#     def forward_fc(self, x, dropout=False):
#         # x = self.global_pool(x).flatten(1)
#         x = self.fc(x.flatten(1))
#         # if dropout and 6 in self.cfg.ib_layers:
#         #     x = F.dropout(x, p=self.cfg.ib_rate)
#         return x
#
#     def forward_higher(self, x, start_index=None, skip_first_pool=False):
#
#         result = {}
#         if start_index < 5:
#             result = self.forward_features(x, start_index=start_index, skip_first_pool=skip_first_pool)
#             x = result['feat']
#         cls = self.forward_fc(x)
#
#         result['cls'] = cls
#         result['Predictions'] = F.softmax(input=cls, dim=-1)
#         return result
#
#     def save_gradient(self, grad):
#         self.gradients.append(grad)
#
#     def _hook_layers(self, layer_list=None, feat=True, grad=True, gate_level='channel'):
#
#         def forward_hook_function(module, ten_in, ten_out):
#             self.hook_feats_in.append(ten_in)
#             self.hook_feats_out.append(ten_out)
#
#         def backward_hook_function(module, grad_in, grad_out):
#             self.hook_grads_in.append(grad_in[0])
#             self.hook_grads_out.append(grad_out[0])
#
#         def get_last_conv_name(net):
#             layer_name = None
#             for name, m in net.named_modules():
#                 if isinstance(m, nn.Conv2d):
#                     layer_name = name
#             self.hook_modules.append(layer_name)
#             return layer_name
#
#         if gate_level == 'pixel':
#             for conv_layer in layer_list:
#
#                 if conv_layer < 5:
#                     layer = 'layer{index}'.format(index=conv_layer)
#                     module_name = get_last_conv_name(self.__getattr__(layer))
#                     for (name, module) in self.named_modules():
#                         if name == layer + '.' + module_name:
#                             if feat:
#                                 self.hook_handlers.append(module.register_forward_hook(forward_hook_function))
#                             if grad:
#                                 self.hook_handlers.append(module.register_backward_hook(backward_hook_function))
#                 else:
#                     if conv_layer > 4:
#                         layer = 'fc'
#
#                     if hasattr(self, layer):
#                         if feat:
#                             self.hook_handlers.append(
#                                 self.__getattr__(layer).register_forward_hook(forward_hook_function))
#                         if grad:
#                             self.hook_handlers.append(
#                                 self.__getattr__(layer).register_backward_hook(backward_hook_function))
#         elif gate_level == 'channel':
#             for conv_layer in layer_list:
#                 layer = 'layer{index}'.format(index=conv_layer)
#                 if layer == 'layer5':
#                     layer = 'global_pool'
#                 if layer == 'layer6':
#                     layer = 'fc'
#                 if hasattr(self, layer):
#                     if feat:
#                         self.hook_handlers.append(
#                             self.__getattr__(layer).register_forward_hook(forward_hook_function))
#                     if grad:
#                         self.hook_handlers.append(
#                             self.__getattr__(layer).register_backward_hook(backward_hook_function))
#         else:
#             raise ValueError('gate level {} not supported!!!!'.format(gate_level))
#
#         # # fc
#         # if 5 in layer_list:
#         #
#         #     def forward_hook_fc_function(module, ten_in, ten_out):
#         #         self.hook_fc_out.append(ten_out[0].data)
#         #
#         #     def backward_hook_fc_function(module, grad_in, grad_out):
#         #         self.hook_fc_grads_out.append(grad_out[0].data)
#         #
#         #     self.hook_handlers.append(
#         #         self.__getattr__('fc').register_forward_hook(forward_hook_fc_function))
#         #     self.hook_handlers.append(
#         #         self.__getattr__('fc').register_backward_hook(backward_hook_fc_function))
#
#
#     def backprop(self, scores, class_idx):
#         """Backpropagate the loss for a specific output class"""
#
#         # loss = scores[:, class_idx].sum()
#
#         # loss = sum([s[class_idx[i]] for i, s in enumerate(scores)])
#
#         # class_num = scores.shape[1]
#         # index = class_idx
#         # num_rois = scores.shape[0]
#         # sp_i = torch.ones([2, num_rois]).long()
#         # sp_i[0, :] = torch.arange(num_rois)
#         # sp_i[1, :] = index
#         # sp_v = torch.ones([num_rois])
#         # one_hot_sparse = torch.sparse.FloatTensor(sp_i, sp_v, torch.Size([num_rois, class_num])).to_dense().cuda()
#         # one_hot = torch.sum(scores * one_hot_sparse)
#
#         # loss = scores[list(range(scores.size()[0])), class_idx].sum()
#         # loss = scores[:, class_idx].sum()
#         loss = self.ce_loss(scores, class_idx)
#         self.zero_grad()
#         loss.backward(retain_graph=True)
#
#
#     def clear_hooks(self):
#         """Clear model hooks"""
#         self.hook_feats_in.clear()
#         self.hook_feats_out.clear()
#         self.hook_grads_in.clear()
#         self.hook_grads_out.clear()
#         self.hook_fc_out.clear()
#         self.hook_fc_grads_out.clear()
#         self.hook_modules.clear()
#         self.gradients.clear()
#         for h in self.hook_handlers:
#             h.remove()
#
#
#
# class Domain_Specific_ResNet(Base_Domain_Specific_Network):
#
#     def __init__(self, cfg, model=None, name=''):
#         super().__init__(cfg)
#
#         self.cfg = cfg
#         if 'resnet18' in model:
#             print('use resnet18')
#             net = resnet18(pretrained=cfg.pretrained)
#         else:
#             # print('use resnet50')
#             net = resnet50(pretrained=cfg.pretrained)
#
#         self.maxpool = net.maxpool
#         self.layer0 = nn.Sequential(net.conv1, net.bn1, net.relu)
#         self.layer1 = net.layer1
#         self.layer2 = net.layer2
#         self.layer3 = net.layer3
#         self.layer4 = net.layer4
#         self.global_pool = nn.AdaptiveAvgPool2d(1)
#         self.fc = nn.Linear(net.fc.in_features, cfg.num_classes)
#         self.maxpool_layers = [1]
#         self.name = name
#
# class AlexNetCaffe(nn.Module):
#     def __init__(self, n_classes=100):
#         super(AlexNetCaffe, self).__init__()
#         print("Using Caffe AlexNet")
#         self.features = nn.Sequential(OrderedDict([
#             ("conv1", nn.Conv2d(3, 96, kernel_size=11, stride=4)),
#             ("relu1", nn.ReLU(inplace=True)),
#             ("pool1", nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True)),
#             ("norm1", nn.LocalResponseNorm(5, 1.e-4, 0.75)),
#             ("conv2", nn.Conv2d(96, 256, kernel_size=5, padding=2, groups=2)),
#             ("relu2", nn.ReLU(inplace=True)),
#             ("pool2", nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True)),
#             ("norm2", nn.LocalResponseNorm(5, 1.e-4, 0.75)),
#             ("conv3", nn.Conv2d(256, 384, kernel_size=3, padding=1)),
#             ("relu3", nn.ReLU(inplace=True)),
#             ("conv4", nn.Conv2d(384, 384, kernel_size=3, padding=1, groups=2)),
#             ("relu4", nn.ReLU(inplace=True)),
#             ("conv5", nn.Conv2d(384, 256, kernel_size=3, padding=1, groups=2)),
#             ("relu5", nn.ReLU(inplace=True)),
#             ("pool5", nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True)),
#         ]))
#         self.classifier = nn.Sequential(OrderedDict([
#             ("fc6", nn.Linear(256 * 6 * 6, 4096)),
#             ("relu6", nn.ReLU(inplace=True)),
#             ("drop6", nn.Dropout()),
#             ("fc7", nn.Linear(4096, 4096)),
#             ("relu7", nn.ReLU(inplace=True)),
#             ("drop7", nn.Dropout())]))
#
#         self.class_classifier = nn.Linear(4096, n_classes)
#
#     def is_patch_based(self):
#         return False
#
#     def forward(self, x, gt=None, flag=None):
#         # x = self.features(x*57.6)  #57.6 is the magic number needed to bring torch data back to the range of caffe data, based on used std
#         # x = x.view(x.size(0), -1)
#         # #d = ReverseLayerF.apply(x, lambda_val)
#         # x = self.classifier(x)
#         # return self.class_classifier(x)#, self.domain_classifier(d)
#         # -------------------------------------------------------------------
#         x = self.features(x * 57.6)
#         x = x.view(x.size(0), -1)
#         x = self.classifier(x)
#         return self.class_classifier(x)  # , self.domain_classifier(d)
#
# def caffenet(classes):
#     model = AlexNetCaffe(classes)
#     for m in model.modules():
#         if isinstance(m, nn.Linear):
#             nn.init.xavier_uniform_(m.weight, .1)
#             nn.init.constant_(m.bias, 0.)
#
#     state_dict = torch.load(os.path.join(os.path.dirname(__file__), "pretrained/alexnet_caffe.pth.tar"))
#     del state_dict["classifier.fc8.weight"]
#     del state_dict["classifier.fc8.bias"]
#     model.load_state_dict(state_dict, strict=False)
#
#     return model
#
# class Domain_Specific_AlexNet(Base_Domain_Specific_Network):
#
#     def __init__(self, cfg, name=''):
#         super().__init__(cfg)
#
#         self.cfg = cfg
#         self.name = name
#
#         if 'alexnet' == cfg.model:
#
#             net = alexnet(pretrained=cfg.pretrained)
#             list_features = list(net.features.children())
#             self.layer0 = nn.Sequential(*list_features[:2])
#             self.layer1 = nn.Sequential(*list_features[3:5])
#             self.layer2 = nn.Sequential(*list_features[6:8])
#             self.layer3 = nn.Sequential(*list_features[8:10])
#             self.layer4 = nn.Sequential(*list_features[10: -1])
#             self.maxpool = list_features[-1]
#             num_ftrs = net.classifier[6].in_features
#             self.fc = net.classifier
#             self.fc[6] = nn.Linear(num_ftrs, cfg.num_classes)
#             self.global_pool = nn.AdaptiveAvgPool2d(output_size=(6, 6))
#             self.maxpool_layers = [1, 2]
#
#         elif 'alexnet_bn' == cfg.model:
#
#             net = alexnet_bn(pretrained=cfg.pretrained)
#             list_features = list(net.features.children())
#             self.layer0 = nn.Sequential(*list_features[:3])
#             self.layer1 = nn.Sequential(*list_features[3:6])
#             self.layer2 = nn.Sequential(*list_features[7:10])
#             self.layer3 = nn.Sequential(*list_features[11:14])
#             self.layer4 = nn.Sequential(*list_features[15:])
#             self.maxpool = nn.MaxPool2d(3, 2)
#             self.fc = nn.Linear(512, cfg.num_classes)
#             self.global_pool = SelectAdaptivePool2d(pool_type='avg')
#
#             self.maxpool_layers = [2, 3, 4]
#         elif 'alexnet_caffe' == cfg.model:
#             net = caffenet(cfg.num_classes)
#             f = net.features
#             self.layer0 = nn.Sequential(f.conv1, f.relu1, f.pool1, f.norm1)
#             self.layer1 = nn.Sequential(f.conv2, f.relu2, f.pool1, f.norm2)
#             self.layer2 = nn.Sequential(f.conv3, f.relu3)
#             self.layer3 = nn.Sequential(f.conv4, f.relu4)
#             self.layer4 = nn.Sequential(f.conv5, f.relu5, f.pool5)
#             self.maxpool = f.pool1
#             self.maxpool_layers = []
#             self.fc = net.classifier
#             self.fc.__setattr__('fc8', net.class_classifier)
#             self.global_pool = nn.AdaptiveAvgPool2d(output_size=(6, 6))
#
#     def _hook_layers(self, layer_list=None, feat=True, grad=True, gate_level='channel'):
#
#         def forward_hook_fc_function(module, ten_in, ten_out):
#             self.hook_fc_out.append(ten_out.data)
#
#         def backward_hook_fc_function(module, grad_in, grad_out):
#             self.hook_fc_grads_out.append(grad_out[0].data)
#
#         super()._hook_layers(layer_list, feat, grad, gate_level)
#
#         if self.cfg.ib_fc_layers[0] >= 0:
#             for l in self.cfg.ib_fc_layers:
#                 self.hook_handlers.append(
#                     self.__getattr__('fc')[l].register_forward_hook(forward_hook_fc_function))
#                 self.hook_handlers.append(
#                     self.__getattr__('fc')[l].register_backward_hook(backward_hook_fc_function))
#
#     # def forward_features(self, x, start_index=0, return_layer=None, skip_first_pool=False):
#     #     result = super().forward_features(x, start_index, return_layer, skip_first_pool=skip_first_pool)
#     #     if return_layer is not None:
#     #         return result
#     #     # result['feat'] = self.maxpool(result['feat'])
#     #     return result
#
#
# # class Domain_Specific_VGG(Base_Domain_Specific_Network):
# #
# #     def __init__(self, cfg):
# #         super().__init__()
# #
# #         self.cfg = cfg
# #         if cfg.model == 'vgg11':
# #             net = vgg_models.vgg11(pretrained=cfg.pretrained)
# #             list_features = list(net.features.children())
# #             self.layer0 = nn.Sequential(*list_features[:2])
# #             self.layer1 = nn.Sequential(*list_features[3:5])
# #             self.layer2 = nn.Sequential(*list_features[6:10])
# #             self.layer3 = nn.Sequential(*list_features[11:15])
# #             self.layer4 = nn.Sequential(*list_features[16: -1])
# #             self.maxpool_layers = [1, 2, 3, 4]
# #         elif cfg.model == 'vgg11_bn':
# #             net = vgg_models.vgg11_bn(pretrained=cfg.pretrained)
# #             list_features = list(net.features.children())
# #             self.layer0 = nn.Sequential(*list_features[:3])
# #             self.layer1 = nn.Sequential(*list_features[4:7])
# #             self.layer2 = nn.Sequential(*list_features[8:14])
# #             self.layer3 = nn.Sequential(*list_features[15:21])
# #             self.layer4 = nn.Sequential(*list_features[22: -1])
# #             self.maxpool_layers = [1, 2, 3, 4]
# #
# #         # num_ftrs = net.classifier[6].in_features
# #         # self.fc = net.classifier
# #         # self.fc[6] = nn.Linear(num_ftrs, cfg.num_classes)
# #         # self.global_pool = nn.AdaptiveAvgPool2d((7, 7))
# #
# #         self.fc = nn.Linear(512, cfg.num_classes)
# #         self.global_pool = SelectAdaptivePool2d(pool_type='avg')
# #
# #         self.maxpool = list_features[-1]
# #
# #     def _hook_layers(self, layer_list=None):
# #         def forward_hook_fc_function(module, ten_in, ten_out):
# #             self.hook_fc_out.append(ten_out[0].data)
# #
# #         def backward_hook_fc_function(module, grad_in, grad_out):
# #             self.hook_fc_grads_out.append(grad_out[0].data)
# #
# #         super()._hook_layers(layer_list)
# #
# #         if self.cfg.ib_fc_layers[0] >=0:
# #             for l in self.cfg.ib_fc_layers:
# #                 self.hook_handlers.append(
# #                     self.__getattr__('fc')[l].register_forward_hook(forward_hook_fc_function))
# #                 self.hook_handlers.append(
# #                     self.__getattr__('fc')[l].register_backward_hook(backward_hook_fc_function))
# #
# #     def forward_features(self, x, start_index=0, return_layer=None, skip_first_pool=False):
# #         result = super().forward_features(x, start_index, return_layer, skip_first_pool=skip_first_pool)
# #         if return_layer is not None:
# #             return result
# #         # result['feat'] = self.maxpool(result['feat'])
# #         return result
#
# # class DropBlock2D(nn.Module):
# #     r"""Randomly zeroes spatial blocks of the input tensor.
# #     As described in the paper
# #     `DropBlock: A regularization method for convolutional networks`_ ,
# #     dropping whole blocks of feature map allows to remove semantic
# #     information as compared to regular dropout.
# #     Args:
# #         keep_prob (float, optional): probability of an element to be kept.
# #         Authors recommend to linearly decrease this value from 1 to desired
# #         value.
# #         block_size (int, optional): size of the block. Block size in paper
# #         usually equals last feature map dimensions.
# #     Shape:
# #         - Input: :math:`(N, C, H, W)`
# #         - Output: :math:`(N, C, H, W)` (same shape as input)
# #     .. _DropBlock: A regularization method for convolutional networks:
# #        https://arxiv.org/abs/1810.12890
# #     """
# #
# #     def __init__(self, keep_prob=0.9, block_size=7):
# #         super(DropBlock2D, self).__init__()
# #         self.keep_prob = keep_prob
# #         self.block_size = block_size
# #
# #     def forward(self, input):
# #         if not self.training or self.keep_prob == 1:
# #             return input
# #         gamma = (1. - self.keep_prob) / self.block_size ** 2
# #         for sh in input.shape[2:]:
# #             gamma *= sh / (sh - self.block_size + 1)
# #         M = torch.bernoulli(torch.ones_like(input) * gamma)
# #         Msum = F.conv2d(M,
# #                         torch.ones((input.shape[1], 1, self.block_size, self.block_size)).to(device=input.device,
# #                                                                                              dtype=input.dtype),
# #                         padding=self.block_size // 2,
# #                         groups=input.shape[1])
# #         torch.set_printoptions(threshold=5000)
# #         mask = (Msum < 1).to(device=input.device, dtype=input.dtype)
# #         return input * mask * mask.numel() /mask.sum()
#
# class DropBlock2D(nn.Module):
#     r"""Randomly zeroes 2D spatial blocks of the input tensor.
#     As described in the paper
#     `DropBlock: A regularization method for convolutional networks`_ ,
#     dropping whole blocks of feature map allows to remove semantic
#     information as compared to regular dropout.
#     Args:
#         drop_prob (float): probability of an element to be dropped.
#         block_size (int): size of the block to drop
#     Shape:
#         - Input: `(N, C, H, W)`
#         - Output: `(N, C, H, W)`
#     .. _DropBlock: A regularization method for convolutional networks:
#        https://arxiv.org/abs/1810.12890
#     """
#
#     def __init__(self, drop_prob, block_size):
#         super(DropBlock2D, self).__init__()
#
#         self.drop_prob = drop_prob
#         self.block_size = block_size
#
#     def forward(self, x):
#         # shape: (bsize, channels, height, width)
#
#         assert x.dim() == 4, \
#             "Expected input with 4 dimensions (bsize, channels, height, width)"
#
#         if not self.training or self.drop_prob == 0.:
#             return x
#         else:
#             # get gamma value
#             gamma = self._compute_gamma(x)
#
#             # sample mask
#             mask = (torch.rand(x.shape[0], *x.shape[2:]) < gamma).float()
#
#             # place mask on input device
#             mask = mask.to(x.device)
#
#             # compute block mask
#             block_mask = self._compute_block_mask(mask)
#
#             # apply block mask
#             out = x * block_mask[:, None, :, :]
#
#             # scale output
#             out = out * block_mask.numel() / block_mask.sum()
#
#             return out
#
#     def _compute_block_mask(self, mask):
#         block_mask = F.max_pool2d(input=mask[:, None, :, :],
#                                   kernel_size=(self.block_size, self.block_size),
#                                   stride=(1, 1),
#                                   padding=self.block_size // 2)
#
#         if self.block_size % 2 == 0:
#             block_mask = block_mask[:, :, :-1, :-1]
#
#         block_mask = 1 - block_mask.squeeze(1)
#
#         return block_mask
#
#     def _compute_gamma(self, x):
#         return self.drop_prob / (self.block_size ** 2)
#
# # class CrossDomain_Dropout(nn.Module):
# #
# #     def __init__(self, drop_prob):
# #         super(CrossDomain_Dropout, self).__init__()
# #         self.drop_prob = drop_prob
# #
# #     def forward(self, x, ):
# #         output = inputs.clone()
# #         if not self.training or self.drop_prob == 0:
# #             return
# class GANDiscriminator(nn.Module):
#     # initializers
#     def __init__(self, cfg, device=None):
#         super(GANDiscriminator, self).__init__()
#         self.cfg = cfg
#         self.device = device
#         norm = nn.BatchNorm2d
#         self.d_downsample_num = 4
#
#         distribute = [
#             nn.Conv2d(512, 1024, kernel_size=3, stride=1, padding=1),
#             nn.LeakyReLU(0.2, inplace=True),
#             nn.Conv2d(1024, 1024, kernel_size=3, stride=1, padding=1),
#             nn.LeakyReLU(0.2, inplace=True),
#             nn.Conv2d(1024, 1, kernel_size=1)
#         ]
#
#         self.criterion = nn.BCELoss() if cfg.no_lsgan else nn.MSELoss()
#         if self.cfg.no_lsgan:
#             distribute.append(nn.Sigmoid())
#
#         self.distribute = nn.Sequential(*distribute)
#         init_weights(self, 'kaiming')
#
#     def forward(self, x, target):
#         # distribution
#         pred = self.distribute(x)
#
#         if target:
#             label = 1
#         else:
#             label = 0
#
#         dis_patch = torch.FloatTensor(pred.size()).fill_(label).to(self.device)
#         loss = self.criterion(pred, dis_patch)
#
#         return loss

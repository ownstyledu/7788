# from functools import reduce
#
# import numpy as np
# import torch
# import torch.nn as nn
# import torch.nn.functional as F
# import torchvision
# import torchvision.models.vgg as vgg_models
# from torch.nn import init
# # from timm.models.resnet import resnet18, resnet50
# from torchvision.models.resnet import resnet18, resnet50
#
# from timm.models.alexnet import alexnet, alexnet_bn
# from timm.models.layers import SelectAdaptivePool2d
# import torch.nn.functional as F
# import random
#
# unloader_img = torchvision.transforms.ToPILImage(mode='RGB')
#
# def init_weights(net, init_type='normal', key='', gain=0.02):
#     print('initialize {key} with {type}'.format(key=key, type=init_type))
#
#     def init_func(m):
#         classname = m.__class__.__name__
#         if hasattr(m, 'weight') and m.weight is not None and m.weight.requires_grad:
#             if classname.find('Conv') != -1 or classname.find('Linear') != -1:
#                 if init_type == 'normal':
#                     init.normal_(m.weight.data, 0.0, gain)
#                 elif init_type == 'xavier':
#                     init.xavier_normal(m.weight.data, gain=gain)
#                 elif init_type == 'kaiming':
#                     init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
#                 elif init_type == 'orthogonal':
#                     init.orthogonal(m.weight.data, gain=gain)
#                 else:
#                     raise NotImplementedError('initialization method [%s] is not implemented' % init_type)
#                 if hasattr(m, 'bias') and m.bias is not None:
#                     init.constant_(m.bias.data, 0.0)
#             elif classname.find('BatchNorm2d') != -1:
#                 init.normal_(m.weight.data, 1.0, gain)
#                 init.constant_(m.bias.data, 0.0)
#
#     net.apply(init_func)
#
# def define_netowrks(cfg):
#     backbone = cfg.model
#     if 'resnet' in backbone:
#         model = Model_ResNet(cfg)
#
#     elif 'alexnet' in backbone:
#         model = Model_Alexnet(cfg)
#     # elif 'vgg' in backbone:
#     #     model = Model_Vgg(cfg)
#     else:
#         raise ValueError('model {0} is not defined'.format(backbone))
#
#     return model
#
# # class Model_DS(nn.Module):
# #
# #     def __init__(self, cfg):
# #         super(Model_DS, self).__init__()
# #         self.cfg = cfg
# #         if cfg.model == 'resnet':
# #             ds_net = Domain_Specific_ResNet(cfg)
# #         self.ds_nets = nn.ModuleList([ds_net for _ in range(3)])
# #
# #     def forward(self, x, index):
# #         return self.ds_nets[index](x)
#
# class DS_Model(nn.Module):
#
#     def __init__(self, cfg):
#         super(DS_Model, self).__init__()
#         self.cfg = cfg
#         # print(self.main_net)
#         if 'resnet' in cfg.ds_model:
#             self.ds_nets = nn.ModuleList([Domain_Specific_ResNet(cfg, cfg.ds_model, cfg.train_domains[i]) for i in range(3)])
#         elif 'alexnet' in cfg.ds_model:
#             self.ds_nets = nn.ModuleList([Domain_Specific_AlexNet(cfg, cfg.train_domains[i]) for i in range(3)])
#
#     def forward_ds(self, x, domain_index):
#         return self.ds_nets[domain_index](x)
#
#     def forward(self, x, domain_index):
#         return self.ds_nets[domain_index](x)
#
#     def clear_hooks(self):
#         """Clear model hooks"""
#         for ds in self.ds_nets:
#             ds.hook_feats_in.clear()
#             ds.hook_feats_out.clear()
#             ds.hook_grads_in.clear()
#             ds.hook_grads_out.clear()
#             ds.hook_fc_out.clear()
#             ds.hook_fc_grads_out.clear()
#             ds.hook_modules.clear()
#             for h in ds.hook_handlers:
#                 h.remove()
#
#
# class Model_ResNet(nn.Module):
#
#     def __init__(self, cfg):
#         super(Model_ResNet, self).__init__()
#         self.cfg = cfg
#         self.main_net = Domain_Specific_ResNet(cfg, cfg.model)
#         # print(self.main_net)
#         self.layers = ['layer1', 'layer2', 'layer3', 'layer4']
#         self.block = DropBlock2D(0.5, 5)
#
#         self.global_pool = nn.AdaptiveAvgPool2d(1)
#         # self.ds_nets = nn.ModuleList([Domain_Specific_ResNet(cfg) for _ in range(3)])
#
#     def unfix_grad(self, net):
#         def fix_func(m):
#             classname = m.__class__.__name__
#             if classname.find('Conv') != -1 or classname.find('BatchNorm2d') != -1 or classname.find('Linear') != -1:
#                 m.weight.requires_grad = True
#                 if m.bias is not None:
#                     m.bias.requires_grad = True
#
#         net.apply(fix_func)
#
#     def fix_grad(self, net):
#         # print(net.__class__.__name__)
#
#         def fix_func(m):
#             classname = m.__class__.__name__
#             if classname.find('Conv') != -1 or classname.find('BatchNorm2d') != -1:
#                 m.weight.requires_grad = False
#                 if m.bias is not None:
#                     m.bias.requires_grad = False
#
#         net.apply(fix_func)
#
#     def change_dropout(self, net, rate):
#         # print(net.__class__.__name__)
#
#         def change_rate(m):
#             classname = m.__class__.__name__
#             if classname.find('Dropout') != -1:
#                 m.p = rate
#
#         net.apply(change_rate)
#
#     def load_weights(self, net_source, net_target):
#         state_dict = net_source.state_dict()
#         for k, v in net_target.state_dict().items():
#             if k in state_dict.keys() and v.size() == state_dict[k].size():
#                 state_dict[k] = v
#             else:
#                 print('not loaded ib module: ', k)
#         net_source.load_state_dict(state_dict)
#
#     def get_1x_lr_params(self):
#         params_1x = {n:p for n, p in self.named_parameters() if 'ds_nets' in n and p.requires_grad}
#         # print('params_1x ', params_1x.keys())
#         return list(params_1x.values())
#
#     def get_10x_lr_params(self):
#         params_10x = {n:p for n, p in self.named_parameters() if 'ds_nets' not in n and p.requires_grad}
#         # print('params_10x ', params_10x.keys())
#         return list(params_10x.values())
#
#     def ib_act(self, ds_feats, source, act_area=None):
#         zeros_t = torch.zeros_like(source)
#         ones_t = torch.ones_like(source)
#
#         if self.cfg.ib_interact == 'random':
#             interact = np.random.choice(['unite', 'intersect'], size=1)[0]
#         else:
#             interact = self.cfg.ib_interact
#
#         if interact == 'single':
#             cross_d_act = ds_feats[0]
#         elif interact == 'unite':
#             cross_d_act = sum(ds_feats)
#         elif interact == 'intersect':
#             cross_d_act = reduce(lambda x, y: x * y, ds_feats)
#         else:
#             raise ValueError('ambiguous action {0} on ib interaction!'.format(self.cfg.ib_interact))
#
#         if act_area == 'similar':
#             mask = torch.where(cross_d_act > 0, ones_t, zeros_t)
#         elif act_area == 'different':
#             mask = torch.where(cross_d_act > 0, zeros_t, ones_t)
#         else:
#             raise ValueError('ib area {0} not supported!!!'.format(act_area))
#
#         # out = self.block(source)
#
#         # input_num = source.size()[0]
#         # indexes_all = [i for i in range(input_num)]
#         # keep_index = random.sample(indexes_all, int(input_num * (1 - self.cfg.ib_rate)))
#         # mask[keep_index] = ones_t[keep_index]
#
#         if self.cfg.mix_ib:
#             input_num = source.size()[0]
#             ib_num = int(input_num * self.cfg.ib_rate)
#             # ib_num = int(input_num * (1 - self.cfg.ib_rate))
#             mask[:ib_num, ] = ones_t[:ib_num, ]
#
#         gated = source * mask
#         ib_rate = len(torch.nonzero(gated, as_tuple=True)[0]) / len(
#            torch.nonzero(source, as_tuple=True)[0])
#         if ib_rate == 0 or ib_rate == 1:
#             return source
#
#         if gated.ndim == 2:
#             return gated
#         else:
#             if self.cfg.scale_drop:
#                 alpha_all = torch.where(source > 0, ones_t, zeros_t).sum() / torch.where(gated > 0, ones_t, zeros_t).sum()
#                 # alpha_s = torch.where(source > 0, ones_t, zeros_t).sum((2, 3))
#                 # alpha_g = torch.where(gated > 0, ones_t, zeros_t).sum((2, 3))
#                 # alpha_s1 = source.mean((2, 3))
#                 # alpha_g1 = gated.mean((2, 3))
#
#                 # scale = torch.where(alpha_g > 0, alpha_s / alpha_g, torch.ones_like(alpha_g))
#                 # scale = torch.where(scale > alpha_all, torch.ones_like(scale) * alpha_all, scale)
#                 # return gated * scale.unsqueeze(-1).unsqueeze(-1)
#                 return gated * alpha_all
#             else:
#                 return gated
#
#     def forward_ds(self, x, domain_index):
#         return self.ds_nets[domain_index](x)
#
#     def forward_ds_higher(self, x, domain_index, skip_first_pool=False):
#         return self.ds_nets[domain_index].forward_higher(x, skip_first_pool=skip_first_pool)
#
#     def forward(self, x, dropout=False):
#         return self.main_net(x, dropout=dropout)
#
#     def _get_crossdomain_act(self, hook_a, hook_g, gated_strategy='channel'):
#         # assert hook_g.ndim in [2, 4]
#         if hook_g.ndim == 2:
#             weights = hook_g.detach()
#             return F.relu(hook_a.detach() * weights, inplace=True)
#         elif gated_strategy == 'channel':
#             weights = hook_g.detach().mean(axis=(2, 3)).unsqueeze(-1).unsqueeze(-1)
#             return F.relu(hook_a.detach() * weights, inplace=True)
#         elif gated_strategy == 'spatial':
#             # spatial
#             weights = torch.mean(hook_g.detach(), dim=1, keepdim=True)
#             return F.relu(hook_a.detach() * weights, inplace=True)
#         elif gated_strategy == 'both':
#             weights_c = hook_g.detach().mean(axis=(2, 3)).unsqueeze(-1).unsqueeze(-1)
#             a_c = F.relu(hook_a.detach() * weights_c, inplace=True)
#
#             weights_s = torch.mean(hook_g.detach(), dim=1, keepdim=True)
#             a_s = F.relu(hook_a.detach() * weights_s, inplace=True)
#             return a_c * a_s
#         elif gated_strategy == 'pp':
#             grad_2 = hook_g.pow(2)
#             grad_3 = hook_g.pow(3)
#             alpha = grad_2 / (2 * grad_2 + (grad_3 * hook_a).sum(axis=(2, 3), keepdims=True))
#             weights = alpha.squeeze_(0).mul_(torch.relu(hook_g.squeeze(0)))
#             return F.relu(hook_a.detach() * weights, inplace=True)
#
#
#     def forward_ib_grad(self, x, index_cross, labels, act_area, ib_layers=None, ds_model=None, gated_strategy='channel', current_index=None):
#
#         result = {}
#         for index in index_cross:
#             ds_net = ds_model.ds_nets[index]
#             ds_net.eval()
#             if ib_layers is None:
#                 ib_layers = self.cfg.ib_layers
#             ds_net._hook_layers(ib_layers, hook_before_relu=self.cfg.hook_before_relu)
#             ds_result = ds_net(x)
#             ds_net._backprop(ds_result['cls'], labels)
#
#         # act_ds = []
#         act_main_ori = []
#         act_main_ib = []
#
#         if self.cfg.mask == 'main':
#             self.main_net._hook_layers(ib_layers, grad=False)
#
#         for l in range(0, 7):
#
#             if l in self.main_net.maxpool_layers:
#                 x = self.main_net.maxpool(x)
#
#             if l < 5:
#                 layer = 'layer{index}'.format(index=l)
#                 x = self.main_net.__getattr__(layer)(x)
#                 result[layer] = x
#             elif l == 5:
#                 x = self.main_net.global_pool(x)
#             else:
#                 x = self.main_net.fc(x.flatten(1))
#
#             if l in ib_layers:
#                 act_ds = []
#                 for index in index_cross:
#                     ds_net = ds_model.ds_nets[index]
#                     hook_a = ds_net.hook_feats_out[0]
#                     hook_g = ds_net.hook_grads_out[-1]
#                     # hook_a = ds_net.hook_feats_in[0]
#                     assert x.size() == hook_g.size()
#                     assert hook_a.size() == hook_g.size()
#                     if self.cfg.mask == 'ds':
#                         act = hook_a
#                     elif self.cfg.mask == 'main':
#                         act = self.main_net.hook_feats_out[0]
#                     elif self.cfg.mask == 'bug':
#                         act = hook_a[0]
#
#                     guided_act = self._get_crossdomain_act(act, hook_g, gated_strategy=gated_strategy)
#                     result['ds_{}_{}'.format(str(index), layer)] = guided_act
#
#                     act_ds.append(guided_act)
#                     # del ds_net.hook_feats_in[0]
#                     ds_net.hook_feats_out.pop(0)
#                     ds_net.hook_grads_out.pop(-1)
#                     if self.main_net.hook_feats_out:
#                         self.main_net.hook_feats_out.pop(0)
#
#                 act_main_ori.append(x.detach())
#                 if self.cfg.self_chlg and self.cfg.ib_interact == 'single' and current_index == index_cross[0]:
#                     act_area = 'different'
#
#                 x = self.ib_act(act_ds, x, act_area)
#                 # x[ib_index] = self.ib_act(act_ds, x, act_area)[ib_index]
#                 act_main_ib.append(x.detach())
#
#                 result['ib_' + layer] = x
#
#             if l < 6:
#                 result['feat'] = x
#             else:
#                 result['cls'] = x
#
#         ds_model.clear_hooks()
#         self.clear_hooks()
#         result.update(self._cal_ib_preserve_rate(act_main_ori, act_main_ib, ib_layers))
#         return result
#
#     def forward_ib_grad_a(self, x, index_cross, labels, act_area, ib_layers=None, ds_model=None, gated_strategy='channel', current_index=None):
#
#         result = {}
#
#         # act_ds = []
#         act_main_ori = []
#         act_main_ib = []
#         self.main_net._hook_layers(ib_layers, grad=False)
#
#         for l in range(0, 7):
#
#             if l in self.main_net.maxpool_layers:
#                 x = self.main_net.maxpool(x)
#
#             if l < 5:
#                 layer = 'layer{index}'.format(index=l)
#                 x = self.main_net.__getattr__(layer)(x)
#                 result[layer] = x
#             elif l == 5:
#                 x = self.main_net.global_pool(x)
#             else:
#                 x = self.main_net.fc(x.flatten(1))
#
#             if l in ib_layers:
#                 hook_a_main = self.main_net.hook_feats_in[0][0]
#                 for index in index_cross:
#                     act_ds = []
#
#                     ds_net = ds_model.ds_nets[index]
#                     ds_net._hook_layers([l])
#                     ds_net.eval()
#
#                     ds_result = ds_net.forward_higher(hook_a_main.detach(), l, skip_first_pool=True)
#                     ds_net._backprop(ds_result['cls'], labels)
#
#                     hook_a = ds_net.hook_feats_out[0]
#                     hook_g = ds_net.hook_grads_out[-1]
#
#                     if self.cfg.mask == 'ds':
#                         act = hook_a
#                     elif self.cfg.mask == 'main':
#                         act = self.main_net.hook_feats_out[0]
#                     elif self.cfg.mask == 'bug':
#                         act = hook_a[0]
#
#                     act_ds.append(self._get_crossdomain_act(act, hook_g, gated_strategy=gated_strategy))
#                     del ds_net.hook_feats_out[0]
#                     del ds_net.hook_grads_out[-1]
#                     ds_model.clear_hooks()
#
#                 self.main_net.hook_feats_in = []
#                 self.main_net.hook_feats_out = []
#
#
#                 act_main_ori.append(x.detach())
#                 x = self.ib_act(act_ds, x, act_area)
#                 act_main_ib.append(x.detach())
#
#             # result['ib_' + layer] = x
#
#             # self.main_net.hook_handlers.clear()
#             if l < 6:
#                 result['feat'] = x
#             else:
#                 result['cls'] = x
#
#         self.main_net.clear_hooks()
#         result.update(self._cal_ib_preserve_rate(act_main_ori, act_main_ib, ib_layers))
#         return result
#
#     def forward_ib_fc(self, x, index_cross, act_main_ori, act_main_ib, act_area, ds_model, gated_strategy):
#         x = self.main_net.global_pool(x).flatten(1)
#
#         if isinstance(self.main_net.fc, nn.Linear):
#             x = self.main_net.fc(x)
#             act_ds = []
#             for index in index_cross:
#                 ds_net = ds_model.ds_nets[index]
#                 hook_a = ds_net.hook_fc_out[0]
#                 hook_g = ds_net.hook_fc_grads_out[-1]
#                 act_ds.append(self._get_crossdomain_act(hook_a, hook_g, gated_strategy))
#                 del ds_net.hook_fc_out[0]
#                 del ds_net.hook_fc_grads_out[-1]
#
#             act_main_ori.append(x.detach())
#             x = self.ib_act(act_ds, x, act_area)
#             act_main_ib.append(x.detach())
#         else:
#             for l in range(0, len(self.main_net.fc)):
#                 x = self.main_net.fc[l](x)
#                 if l in self.cfg.ib_fc_layers:
#                     act_ds = []
#                     for index in index_cross:
#                         ds_net = ds_model.ds_nets[index]
#                         hook_a = ds_net.hook_fc_out[0]
#                         hook_g = ds_net.hook_fc_grads_out[-1]
#                         act_ds.append(self._get_crossdomain_act(hook_a, hook_g, gated_strategy))
#                         del ds_net.hook_fc_out[0]
#                         del ds_net.hook_fc_grads_out[-1]
#
#                     act_main_ori.append(x.detach())
#                     x = self.ib_act(act_ds, x, act_area)
#                     act_main_ib.append(x.detach())
#
#         return x
#
#     def set_requires_grad(self, net, requires_grad=False):
#
#         for name, param in net.named_parameters():
#             param.requires_grad = requires_grad
#
#     def _cal_ib_preserve_rate(self, feat_ori_list, feat_ib_list, ib_layers):
#         result = {}
#         for i, l in enumerate(ib_layers):
#             if l < 5:
#                 l = 'layer' + str(l)
#             elif l == 5:
#                 l = 'avgpool'
#             else:
#                 l = 'fc'
#             feat_ori = feat_ori_list[i]
#             feat_ib = feat_ib_list[i]
#             try:
#                 ib_rate = len(torch.nonzero(feat_ib, as_tuple=True)[0]) / len(
#                     torch.nonzero(feat_ori, as_tuple=True)[0])
#
#             except ZeroDivisionError:
#                 raise ValueError('{0} is all zeros, can not be divided.'.format(l))
#             result['ib_preserve_rate_' + l] = ib_rate
#
#         # if ib_fc_layers[0] > -1:
#         #
#         #     offset = 0 if ib_layers[0] > 4 else len(ib_layers)
#         #
#         #     for i, l in enumerate(ib_fc_layers):
#         #         l = 'fc.' + str(l)
#         #         feat_ori = feat_ori_list[i + offset]
#         #         feat_ib = feat_ib_list[i + offset]
#         #         try:
#         #             ib_rate = len(torch.nonzero(feat_ib, as_tuple=True)[0]) / len(
#         #                 torch.nonzero(feat_ori, as_tuple=True)[0])
#         #
#         #         except ZeroDivisionError:
#         #             raise ValueError('{0} is all zeros, can not be divided.'.format(l))
#         #         result['ib_preserve_rate_' + l] = ib_rate
#         return result
#
#     def clear_hooks(self):
#         """Clear model hooks"""
#         self.main_net.hook_feats_in.clear()
#         self.main_net.hook_feats_out.clear()
#         self.main_net.hook_grads_in.clear()
#         self.main_net.hook_grads_out.clear()
#         self.main_net.hook_fc_out.clear()
#         self.main_net.hook_fc_grads_out.clear()
#         for h in self.main_net.hook_handlers:
#             h.remove()
#
#     # def clear_hooks(self):
#     #     """Clear model hooks"""
#     #     self.hook_feats_out.clear()
#     #     self.hook_grads_out.clear()
#     #     for h in self.hook_handlers:
#     #         h.remove()
#
#     # def _backprop(self, model, scores, class_idx):
#     #     """Backpropagate the loss for a specific output class"""
#     #
#     #     if not self.hook_feats_out:
#     #         raise TypeError("Inputs need to be forwarded in the model for the conv features to be hooked")
#     #
#     #     # Backpropagate to get the gradients on the hooked layer
#     #     loss = scores[:, class_idx].sum()
#     #     model.zero_grad()
#     #     loss.backward(retain_graph=True)
#
#     @staticmethod
#     def _normalize(cam):
#
#         cam -= np.min(cam)
#         cam /= np.max(cam)
#
#         return cam
#     # def _normalize(cams):
#     #     """CAM normalization"""
#     #     cams -= cams.flatten(start_dim=-2).min(-1).values.unsqueeze(-1).unsqueeze(-1)
#     #     cams /= cams.flatten(start_dim=-2).max(-1).values.unsqueeze(-1).unsqueeze(-1)
#     #
#     #     return cams
#
#
# class Model_Alexnet(Model_ResNet):
#
#     def __init__(self, cfg):
#         super(Model_Alexnet, self).__init__(cfg)
#
#         self.cfg = cfg
#         self.main_net = Domain_Specific_AlexNet(cfg)
#         # init_weights(self.main_net.fc, 'normal')
#         if cfg.ib_fc_layers[0] >= 0:
#             self.main_net.fc[0].p = 0
#             self.main_net.fc[3].p = 0
#
#         self.ds_nets = nn.ModuleList([Domain_Specific_AlexNet(cfg) for _ in range(3)])
#         # for ds_net in self.ds_nets:
#         #     ds_net.fc = nn.Linear(256, cfg.num_classes)
#
#         self.hook_feats_out = []
#         self.hook_grads_out = []
#         self.hook_handlers = []
#         self.gradients = []
#
#         # init_weights(self.main_net.fc[6])
#
#     def forward(self, x):
#         result = self.main_net.forward(x)
#         return result
#
#     def forward_ds(self, x, domain_index):
#         result = {}
#         ds_net = self.ds_nets[domain_index]
#         x = ds_net.forward_features(x)
#         x = ds_net.global_pool(x['feat']).flatten(1)
#         x = ds_net.fc(x)
#         result['cls'] = x
#         result['Predictions'] = F.softmax(input=x, dim=-1)
#         return result
#
#
# # class Model_Vgg(Model_ResNet):
# #
# #     def __init__(self, cfg):
# #         super(Model_Vgg, self).__init__(cfg)
# #
# #         self.cfg = cfg
# #         self.main_net = Domain_Specific_VGG(cfg)
# #         # init_weights(self.main_net.fc, 'normal')
# #         if cfg.ib_fc_layers[0] >= 0:
# #             self.main_net.fc[0].p = 0
# #             self.main_net.fc[3].p = 0
# #
# #         self.ds_nets = nn.ModuleList([Domain_Specific_VGG(cfg) for _ in range(3)])
# #         # for ds_net in self.ds_nets:
# #         #     ds_net.fc = nn.Linear(256, cfg.num_classes)
# #
# #         self.hook_feats_out = []
# #         self.hook_grads_out = []
# #         self.hook_handlers = []
# #         self.gradients = []
# #
# #         # init_weights(self.main_net.fc[6])
# #
# #     def forward(self, x):
# #         result = self.main_net.forward(x)
# #         return result
# #
# #     def forward_ds(self, x, domain_index):
# #         result = {}
# #         ds_net = self.ds_nets[domain_index]
# #         x = ds_net.forward_features(x)
# #         x = ds_net.global_pool(x['feat']).flatten(1)
# #         x = ds_net.fc(x)
# #         result['cls'] = x
# #         result['Predictions'] = F.softmax(input=x, dim=-1)
# #         return result
#
# class Base_Domain_Specific_Network(nn.Module):
#
#     def __init__(self, cfg):
#         super(Base_Domain_Specific_Network, self).__init__()
#
#         self.cfg = cfg
#         self.hook_feats_in = []
#         self.hook_feats_out = []
#         self.hook_grads_in = []
#         self.hook_grads_out = []
#         self.hook_fc_out = []
#         self.hook_fc_grads_out = []
#         self.hook_handlers = []
#         self.hook_modules = []
#
#         # if 'dropout' in cfg.model:
#         #     for l in cfg.ib_layers:
#         #         assert l in list(np.range(7))
#         #         if l < 5:
#         #             layer = 'layer' + str(l)
#         #         elif l == 5:
#         #             layer = 'global_pool'
#         #         else:
#         #             layer = 'fc'
#         #         self.__setattr__(layer, nn.Sequential(self.__getattr__(layer), nn.Dropout2d(cfg.ib_rate)))
#
#     def forward(self, x, dropout=False):
#
#         result = self.forward_features(x, dropout=dropout)
#         cls = self.forward_fc(result['feat'])
#         result['cls'] = cls
#         result['Predictions'] = F.softmax(input=cls, dim=-1)
#         return result
#
#     def forward_features(self, x, start_index=0, return_layer=None, skip_first_pool=False, dropout=False):
#         result = {}
#         for l in range(start_index, 4 + 1):
#             if l in self.maxpool_layers and not (skip_first_pool and l == start_index):
#                 x = self.maxpool(x)
#             layer = 'layer{index}'.format(index=l)
#             x = self.__getattr__(layer)(x)
#             if dropout and l in self.cfg.ib_layers:
#                 x = F.dropout2d(x, p=self.cfg.drop_rate)
#             result[layer] = x
#             if return_layer is not None and l == return_layer:
#                 result['feat'] = x
#                 return result
#         x = self.global_pool(x)
#         # if dropout and 5 in self.cfg.ib_layers:
#         #     x = F.dropout2d(x, p=self.cfg.ib_rate)
#         result['feat'] = x
#         return result
#
#     def forward_fc(self, x, dropout=False):
#         # x = self.global_pool(x).flatten(1)
#         x = self.fc(x.flatten(1))
#         # if dropout and 6 in self.cfg.ib_layers:
#         #     x = F.dropout(x, p=self.cfg.ib_rate)
#         return x
#
#     def forward_higher(self, x, start_index=None, skip_first_pool=False):
#
#         if start_index is None:
#             start_index = self.cfg.shared_layer + 1
#         else:
#             start_index = start_index
#
#         result = self.forward_features(x, start_index=start_index, skip_first_pool=skip_first_pool)
#         cls = self.forward_fc(result['feat'])
#
#         result['cls'] = cls
#         result['Predictions'] = F.softmax(input=cls, dim=-1)
#         return result
#
#     def _hook_layers(self, layer_list=None, feat=True, grad=True, hook_before_relu=None):
#
#         def forward_hook_function(module, ten_in, ten_out):
#             self.hook_feats_in.append(ten_in)
#             self.hook_feats_out.append(ten_out)
#
#         def backward_hook_function(module, grad_in, grad_out):
#             self.hook_grads_in.append(grad_in)
#             self.hook_grads_out.append(grad_out[0])
#
#         def get_last_conv_name(net):
#             layer_name = None
#             for name, m in net.named_modules():
#                 if isinstance(m, nn.Conv2d):
#                     layer_name = name
#             self.hook_modules.append(layer_name)
#             return layer_name
#
#         if hook_before_relu:
#             for conv_layer in layer_list:
#
#                 if conv_layer < 5:
#                     layer = 'layer{index}'.format(index=conv_layer)
#                     module_name = get_last_conv_name(self.__getattr__(layer))
#                     for (name, module) in self.named_modules():
#                         if name == layer + '.' + module_name:
#                             if feat:
#                                 self.hook_handlers.append(module.register_forward_hook(forward_hook_function))
#                             if grad:
#                                 self.hook_handlers.append(module.register_backward_hook(backward_hook_function))
#                 else:
#                     if conv_layer == 5:
#                         layer = 'global_pool'
#                     elif conv_layer == 6:
#                         layer = 'fc'
#
#                     if hasattr(self, layer):
#                         if feat:
#                             self.hook_handlers.append(
#                                 self.__getattr__(layer).register_forward_hook(forward_hook_function))
#                         if grad:
#                             self.hook_handlers.append(
#                                 self.__getattr__(layer).register_backward_hook(backward_hook_function))
#         else:
#             for conv_layer in layer_list:
#                 layer = 'layer{index}'.format(index=conv_layer)
#                 if layer == 'layer5':
#                     layer = 'global_pool'
#                 if layer == 'layer6':
#                     layer = 'fc'
#                 if hasattr(self, layer):
#                     if feat:
#                         self.hook_handlers.append(
#                             self.__getattr__(layer).register_forward_hook(forward_hook_function))
#                     if grad:
#                         self.hook_handlers.append(
#                             self.__getattr__(layer).register_backward_hook(backward_hook_function))
#
#         # # fc
#         # if 5 in layer_list:
#         #
#         #     def forward_hook_fc_function(module, ten_in, ten_out):
#         #         self.hook_fc_out.append(ten_out[0].data)
#         #
#         #     def backward_hook_fc_function(module, grad_in, grad_out):
#         #         self.hook_fc_grads_out.append(grad_out[0].data)
#         #
#         #     self.hook_handlers.append(
#         #         self.__getattr__('fc').register_forward_hook(forward_hook_fc_function))
#         #     self.hook_handlers.append(
#         #         self.__getattr__('fc').register_backward_hook(backward_hook_fc_function))
#
#
#     def _backprop(self, scores, class_idx):
#         """Backpropagate the loss for a specific output class"""
#
#         # if not self.hook_feats_out and not self.hook_fc_out:
#         #     raise TypeError("Inputs need to be forwarded in the model for the conv features to be hooked")
#
#         # Backpropagate to get the gradients on the hooked layer
#         loss = scores[:, class_idx].sum()
#         self.zero_grad()
#         loss.backward(retain_graph=True)
#
#
#     def clear_hooks(self):
#         """Clear model hooks"""
#         self.hook_feats_in.clear()
#         self.hook_feats_out.clear()
#         self.hook_grads_in.clear()
#         self.hook_grads_out.clear()
#         self.hook_fc_out.clear()
#         self.hook_fc_grads_out.clear()
#         self.hook_modules.clear()
#         for h in self.hook_handlers:
#             h.remove()
#
#
#
# class Domain_Specific_ResNet(Base_Domain_Specific_Network):
#
#     def __init__(self, cfg, model=None, name=''):
#         super().__init__(cfg)
#
#         self.cfg = cfg
#         if 'resnet18' in model:
#             net = resnet18(pretrained=cfg.pretrained)
#         else:
#             net = resnet50(pretrained=cfg.pretrained)
#
#         self.maxpool = net.maxpool
#         self.layer0 = nn.Sequential(net.conv1, net.bn1, net.relu)
#         self.layer1 = net.layer1
#         self.layer2 = net.layer2
#         self.layer3 = net.layer3
#         self.layer4 = net.layer4
#         self.global_pool = nn.AdaptiveAvgPool2d(1)
#         self.fc = nn.Linear(net.fc.in_features, cfg.num_classes)
#         self.maxpool_layers = [1]
#         self.name = name
#
#
#
#
# class Domain_Specific_AlexNet(Base_Domain_Specific_Network):
#
#     def __init__(self, cfg, name=''):
#         super().__init__()
#
#         self.cfg = cfg
#         self.name = name
#
#         if 'alexnet' == cfg.model:
#
#             net = alexnet(pretrained=cfg.pretrained)
#             list_features = list(net.features.children())
#             self.layer0 = nn.Sequential(*list_features[:2])
#             self.layer1 = nn.Sequential(*list_features[3:5])
#             self.layer2 = nn.Sequential(*list_features[6:8])
#             self.layer3 = nn.Sequential(*list_features[8:10])
#             self.layer4 = nn.Sequential(*list_features[10: -1])
#             self.maxpool = list_features[-1]
#             num_ftrs = net.classifier[6].in_features
#             self.fc = net.classifier
#             self.fc[6] = nn.Linear(num_ftrs, cfg.num_classes)
#             self.global_pool = nn.AdaptiveAvgPool2d(output_size=(6, 6))
#             self.maxpool_layers = [1, 2]
#
#         elif 'alexnet_bn' == cfg.model:
#
#             net = alexnet_bn(pretrained=cfg.pretrained)
#             list_features = list(net.features.children())
#             self.layer0 = nn.Sequential(*list_features[:3])
#             self.layer1 = nn.Sequential(*list_features[3:6])
#             self.layer2 = nn.Sequential(*list_features[7:10])
#             self.layer3 = nn.Sequential(*list_features[11:14])
#             self.layer4 = nn.Sequential(*list_features[15:])
#             self.maxpool = nn.MaxPool2d(3, 2)
#             self.fc = nn.Linear(512, cfg.num_classes)
#             self.global_pool = SelectAdaptivePool2d(pool_type='avg')
#
#             self.maxpool_layers = [2, 3, 4]
#
#     # def _hook_layers(self, layer_list=None):
#     #
#     #     def forward_hook_fc_function(module, ten_in, ten_out):
#     #         self.hook_fc_out.append(ten_out[0].data)
#     #
#     #     def backward_hook_fc_function(module, grad_in, grad_out):
#     #         self.hook_fc_grads_out.append(grad_out[0].data)
#     #
#     #     super()._hook_layers(layer_list)
#     #
#     #     if self.cfg.ib_fc_layers[0] >=0:
#     #         for l in self.cfg.ib_fc_layers:
#     #             self.hook_handlers.append(
#     #                 self.__getattr__('fc')[l].register_forward_hook(forward_hook_fc_function))
#     #             self.hook_handlers.append(
#     #                 self.__getattr__('fc')[l].register_backward_hook(backward_hook_fc_function))
#
#     def forward_features(self, x, start_index=0, return_layer=None, skip_first_pool=False):
#         result = super().forward_features(x, start_index, return_layer, skip_first_pool=skip_first_pool)
#         if return_layer is not None:
#             return result
#         # result['feat'] = self.maxpool(result['feat'])
#         return result
#
#
# # class Domain_Specific_VGG(Base_Domain_Specific_Network):
# #
# #     def __init__(self, cfg):
# #         super().__init__()
# #
# #         self.cfg = cfg
# #         if cfg.model == 'vgg11':
# #             net = vgg_models.vgg11(pretrained=cfg.pretrained)
# #             list_features = list(net.features.children())
# #             self.layer0 = nn.Sequential(*list_features[:2])
# #             self.layer1 = nn.Sequential(*list_features[3:5])
# #             self.layer2 = nn.Sequential(*list_features[6:10])
# #             self.layer3 = nn.Sequential(*list_features[11:15])
# #             self.layer4 = nn.Sequential(*list_features[16: -1])
# #             self.maxpool_layers = [1, 2, 3, 4]
# #         elif cfg.model == 'vgg11_bn':
# #             net = vgg_models.vgg11_bn(pretrained=cfg.pretrained)
# #             list_features = list(net.features.children())
# #             self.layer0 = nn.Sequential(*list_features[:3])
# #             self.layer1 = nn.Sequential(*list_features[4:7])
# #             self.layer2 = nn.Sequential(*list_features[8:14])
# #             self.layer3 = nn.Sequential(*list_features[15:21])
# #             self.layer4 = nn.Sequential(*list_features[22: -1])
# #             self.maxpool_layers = [1, 2, 3, 4]
# #
# #         # num_ftrs = net.classifier[6].in_features
# #         # self.fc = net.classifier
# #         # self.fc[6] = nn.Linear(num_ftrs, cfg.num_classes)
# #         # self.global_pool = nn.AdaptiveAvgPool2d((7, 7))
# #
# #         self.fc = nn.Linear(512, cfg.num_classes)
# #         self.global_pool = SelectAdaptivePool2d(pool_type='avg')
# #
# #         self.maxpool = list_features[-1]
# #
# #     def _hook_layers(self, layer_list=None):
# #         def forward_hook_fc_function(module, ten_in, ten_out):
# #             self.hook_fc_out.append(ten_out[0].data)
# #
# #         def backward_hook_fc_function(module, grad_in, grad_out):
# #             self.hook_fc_grads_out.append(grad_out[0].data)
# #
# #         super()._hook_layers(layer_list)
# #
# #         if self.cfg.ib_fc_layers[0] >=0:
# #             for l in self.cfg.ib_fc_layers:
# #                 self.hook_handlers.append(
# #                     self.__getattr__('fc')[l].register_forward_hook(forward_hook_fc_function))
# #                 self.hook_handlers.append(
# #                     self.__getattr__('fc')[l].register_backward_hook(backward_hook_fc_function))
# #
# #     def forward_features(self, x, start_index=0, return_layer=None, skip_first_pool=False):
# #         result = super().forward_features(x, start_index, return_layer, skip_first_pool=skip_first_pool)
# #         if return_layer is not None:
# #             return result
# #         # result['feat'] = self.maxpool(result['feat'])
# #         return result
#
# # class DropBlock2D(nn.Module):
# #     r"""Randomly zeroes spatial blocks of the input tensor.
# #     As described in the paper
# #     `DropBlock: A regularization method for convolutional networks`_ ,
# #     dropping whole blocks of feature map allows to remove semantic
# #     information as compared to regular dropout.
# #     Args:
# #         keep_prob (float, optional): probability of an element to be kept.
# #         Authors recommend to linearly decrease this value from 1 to desired
# #         value.
# #         block_size (int, optional): size of the block. Block size in paper
# #         usually equals last feature map dimensions.
# #     Shape:
# #         - Input: :math:`(N, C, H, W)`
# #         - Output: :math:`(N, C, H, W)` (same shape as input)
# #     .. _DropBlock: A regularization method for convolutional networks:
# #        https://arxiv.org/abs/1810.12890
# #     """
# #
# #     def __init__(self, keep_prob=0.9, block_size=7):
# #         super(DropBlock2D, self).__init__()
# #         self.keep_prob = keep_prob
# #         self.block_size = block_size
# #
# #     def forward(self, input):
# #         if not self.training or self.keep_prob == 1:
# #             return input
# #         gamma = (1. - self.keep_prob) / self.block_size ** 2
# #         for sh in input.shape[2:]:
# #             gamma *= sh / (sh - self.block_size + 1)
# #         M = torch.bernoulli(torch.ones_like(input) * gamma)
# #         Msum = F.conv2d(M,
# #                         torch.ones((input.shape[1], 1, self.block_size, self.block_size)).to(device=input.device,
# #                                                                                              dtype=input.dtype),
# #                         padding=self.block_size // 2,
# #                         groups=input.shape[1])
# #         torch.set_printoptions(threshold=5000)
# #         mask = (Msum < 1).to(device=input.device, dtype=input.dtype)
# #         return input * mask * mask.numel() /mask.sum()
#
# class DropBlock2D(nn.Module):
#     r"""Randomly zeroes 2D spatial blocks of the input tensor.
#     As described in the paper
#     `DropBlock: A regularization method for convolutional networks`_ ,
#     dropping whole blocks of feature map allows to remove semantic
#     information as compared to regular dropout.
#     Args:
#         drop_prob (float): probability of an element to be dropped.
#         block_size (int): size of the block to drop
#     Shape:
#         - Input: `(N, C, H, W)`
#         - Output: `(N, C, H, W)`
#     .. _DropBlock: A regularization method for convolutional networks:
#        https://arxiv.org/abs/1810.12890
#     """
#
#     def __init__(self, drop_prob, block_size):
#         super(DropBlock2D, self).__init__()
#
#         self.drop_prob = drop_prob
#         self.block_size = block_size
#
#     def forward(self, x):
#         # shape: (bsize, channels, height, width)
#
#         assert x.dim() == 4, \
#             "Expected input with 4 dimensions (bsize, channels, height, width)"
#
#         if not self.training or self.drop_prob == 0.:
#             return x
#         else:
#             # get gamma value
#             gamma = self._compute_gamma(x)
#
#             # sample mask
#             mask = (torch.rand(x.shape[0], *x.shape[2:]) < gamma).float()
#
#             # place mask on input device
#             mask = mask.to(x.device)
#
#             # compute block mask
#             block_mask = self._compute_block_mask(mask)
#
#             # apply block mask
#             out = x * block_mask[:, None, :, :]
#
#             # scale output
#             out = out * block_mask.numel() / block_mask.sum()
#
#             return out
#
#     def _compute_block_mask(self, mask):
#         block_mask = F.max_pool2d(input=mask[:, None, :, :],
#                                   kernel_size=(self.block_size, self.block_size),
#                                   stride=(1, 1),
#                                   padding=self.block_size // 2)
#
#         if self.block_size % 2 == 0:
#             block_mask = block_mask[:, :, :-1, :-1]
#
#         block_mask = 1 - block_mask.squeeze(1)
#
#         return block_mask
#
#     def _compute_gamma(self, x):
#         return self.drop_prob / (self.block_size ** 2)
#
# # class CrossDomain_Dropout(nn.Module):
# #
# #     def __init__(self, drop_prob):
# #         super(CrossDomain_Dropout, self).__init__()
# #         self.drop_prob = drop_prob
# #
# #     def forward(self, x, ):
# #         output = inputs.clone()
# #         if not self.training or self.drop_prob == 0:
# #             return
# class GANDiscriminator(nn.Module):
#     # initializers
#     def __init__(self, cfg, device=None):
#         super(GANDiscriminator, self).__init__()
#         self.cfg = cfg
#         self.device = device
#         norm = nn.BatchNorm2d
#         self.d_downsample_num = 4
#
#         distribute = [
#             nn.Conv2d(512, 1024, kernel_size=3, stride=1, padding=1),
#             nn.LeakyReLU(0.2, inplace=True),
#             nn.Conv2d(1024, 1024, kernel_size=3, stride=1, padding=1),
#             nn.LeakyReLU(0.2, inplace=True),
#             nn.Conv2d(1024, 1, kernel_size=1)
#         ]
#
#         self.criterion = nn.BCELoss() if cfg.no_lsgan else nn.MSELoss()
#         if self.cfg.no_lsgan:
#             distribute.append(nn.Sigmoid())
#
#         self.distribute = nn.Sequential(*distribute)
#         init_weights(self, 'kaiming')
#
#     def forward(self, x, target):
#         # distribution
#         pred = self.distribute(x)
#
#         if target:
#             label = 1
#         else:
#             label = 0
#
#         dis_patch = torch.FloatTensor(pred.size()).fill_(label).to(self.device)
#         loss = self.criterion(pred, dis_patch)
#
#         return loss

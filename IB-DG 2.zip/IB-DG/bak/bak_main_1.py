# import argparse
# import os
# import sys
# # os.environ['CUDA_VISIBLE_DEVICES'] = '1'
# from datetime import datetime
# import torch
#
# torch.multiprocessing.set_start_method('spawn', force=True)
# from apex import amp
# from apex.parallel import convert_syncbn_model
# from apex.parallel import DistributedDataParallel
# import torch.distributed as distributed
# import torchvision.transforms as transforms
# from common.dataset import Manual_BatchSampler_Dataset
# import torchvision.datasets as datasets
# from torch.utils.data import DataLoader
# import numpy as np
# from sklearn.metrics import accuracy_score
# import random
# import torch.nn as nn
# from models import define_netowrks, Domain_Specific_ResNet, Domain_Specific_AlexNet
# import copy
# from common.average_meter import AverageMeter
# from torch.utils.data import ConcatDataset
# import time
# from colorama import init, Fore, Back, Style
# import torch.nn.functional as F
# from torch.autograd import Variable
# from tensorboardX import SummaryWriter
# import torchvision
# from config.default_config import DefaultConfig
# from config.resnet_PACS import Config_PACS_ResNet
# from config.resnet_VLCS import Config_VLCS_ResNet
# from torchcam.cams.gradcam import GradCAMpp
#
# from apex.parallel import DistributedDataParallel
#
# from torchvision.transforms.functional import normalize, resize, to_tensor, to_pil_image
# from torchcam.utils import overlay_mask
# import torchvision
# from scipy.io import loadmat
# import math
# from utils import send_msg_by_serverchan
# import cv2
# from contiguous_params import ContiguousParams
#
# unloader_img = torchvision.transforms.ToPILImage()
# loader_img = torchvision.transforms.ToTensor()
#
# device = torch.device('cuda')
#
#
# def main():
#     cfg = Config_PACS_ResNet()
#     # cfg = Config_VLCS_ResNet()
#     # args = dict(cfg)
#     # cfg.parse(args)
#
#     if len(sys.argv) == 1:
#         os.environ['CUDA_VISIBLE_DEVICES'] = '1'
#     else:
#         print('args:', sys.argv[1:])
#         os.environ['CUDA_VISIBLE_DEVICES'] = sys.argv[1]
#         param_list = sys.argv[1:]
#         cfg.__setattr__('sys_args', ' '.join(sys.argv[1:]))
#         for para in param_list:
#             result = para.split('=')
#             if len(result) == 1:
#                 continue
#             if len(result) == 2 and result[0] in cfg.keys():
#                 type_param = type(cfg.__getitem__(result[0]))
#                 if type_param == bool:
#                     val = eval(result[1])
#                 elif type_param == list:
#                     type_elem = type(cfg.__getitem__(result[0])[0])
#                     val = [type_elem(i) for i in result[1].split(',')]
#                 else:
#                     val = type_param(result[1])
#                 cfg.__setattr__(result[0], val)
#             else:
#                 raise ValueError('sys args {0} not supported!!!'.format(para))
#
#     cfg.__setattr__('model_path',
#                     os.path.join('checkpoints/models_unseen', str(cfg.unseen_index), cfg.starttime, str(cfg.seed)))
#     if not os.path.exists(cfg.model_path):
#         os.makedirs(cfg.model_path)
#     cfg.resume_path = os.path.join(cfg.model_path, 'best_model.tar')
#
#     torch.backends.cudnn.deterministic = True
#     torch.backends.cudnn.benchmark = True
#
#     seed = cfg.seed
#     print('seed-----------', seed)
#     random.seed(seed)
#     np.random.seed(seed)
#     torch.manual_seed(seed)
#     torch.cuda.manual_seed_all(seed)
#
#     log_path = os.path.join(cfg.writer_path, cfg.task_name + '_' + cfg.starttime)
#     writer = SummaryWriter(logdir=log_path)
#     cfg.__setattr__('log_path', log_path)
#
#     domains = sorted(os.listdir(cfg.data_root))
#     train_paths = [os.path.join(cfg.data_root, d, 'train') for d in domains if
#                    os.path.isdir(os.path.join(cfg.data_root, d, 'train'))]
#     train_paths.pop(cfg.unseen_index)
#     val_paths = [os.path.join(cfg.data_root, d, 'val') for d in domains if
#                  os.path.isdir(os.path.join(cfg.data_root, d, 'val'))]
#     val_paths.pop(cfg.unseen_index)
#     test_domain = domains[cfg.unseen_index]
#     cfg.__setattr__('test_domain', test_domain)
#     test_path = os.path.join(cfg.data_root, test_domain, 'test')
#
#     train_domains = sorted(set(domains) ^ set([domains[cfg.unseen_index]]))
#     cfg.__setattr__('train_domains', train_domains)
#
#     normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
#                                      std=[0.229, 0.224, 0.225])
#     if 'alexnet' in cfg.model:
#         img_size = 227
#     else:
#         img_size = 224
#
#     train_transforms = transforms.Compose([
#         transforms.RandomResizedCrop(img_size, (0.8, 1)),
#         # transforms.Resize(224),
#         # transforms.RandomCrop(224),
#         transforms.RandomHorizontalFlip(),
#         transforms.RandomGrayscale(),
#         transforms.ToTensor(),
#         normalize,
#     ])
#
#     # one domain in one batch
#     train_datasets_isolated = [Manual_BatchSampler_Dataset(cfg, train_p, dom, transforms=train_transforms)
#                                for train_p, dom in zip(train_paths, train_domains)]
#     val_loader_isolated = [DataLoader(
#         datasets.ImageFolder(val_p, transforms.Compose([
#             transforms.Resize(img_size),
#             transforms.ToTensor(),
#             normalize,
#         ])), batch_size=cfg.batch_size, shuffle=False, num_workers=8, pin_memory=True) for val_p in val_paths]
#
#     # randomly sample from domains
#     train_datasets_conc = ConcatDataset([datasets.ImageFolder(train_p, transforms.Compose([
#         transforms.Resize(img_size),
#         transforms.ToTensor(),
#         normalize,
#     ])) for train_p in train_paths])
#
#     val_datasets = ConcatDataset([datasets.ImageFolder(val_p, transforms.Compose([
#         transforms.Resize(img_size),
#         # transforms.CenterCrop(224),
#         transforms.ToTensor(),
#         normalize,
#     ])) for val_p in val_paths])
#
#     train_loader_conc = DataLoader(train_datasets_conc, batch_size=cfg.batch_size, shuffle=True, num_workers=8,
#                                    pin_memory=True)
#     val_loader = DataLoader(val_datasets, batch_size=cfg.batch_size, shuffle=False, num_workers=8, pin_memory=True)
#     test_loader = DataLoader(
#         datasets.ImageFolder(test_path, transforms.Compose([
#             transforms.Resize(img_size),
#             transforms.ToTensor(),
#             normalize,
#         ])),
#         batch_size=cfg.batch_size, shuffle=False,
#         num_workers=8, pin_memory=True)
#
#     # model
#     model = define_netowrks(cfg)
#     if cfg.resume:
#         # load_path = os.path.join(cfg.model_path, cfg.resume_path)
#         load_checkpoint(cfg, model, cfg.resume_path)
#         model = model.to(device)
#         val_workflow(cfg, model, val_loader_isolated, 1, log_dir='logs/')
#         test_workflow(cfg, model, 1, test_loader, writer)
#
#     # loss
#     loss_fn = torch.nn.CrossEntropyLoss().to(device)
#     # loss_fn_f = FocalLoss(cfg.num_classes).to(device)
#
#     train_params = [{'params': model.get_10x_lr_params(), 'lr': cfg.lr},
#                     {'params': model.get_1x_lr_params(), 'lr': cfg.lr_ds}]
#
#     # train_params = model.parameters()
#
#     # train_params = ContiguousParams(train_params)
#     if cfg.optimizer == 'sgd':
#         optimizer = torch.optim.SGD(train_params, lr=cfg.lr, momentum=cfg.momentum, weight_decay=cfg.weight_decay)
#     else:
#         optimizer = torch.optim.Adam(model.parameters(), lr=cfg.lr, betas=(0.5, 0.999))
#
#     scheduler = get_scheduler(cfg, optimizer)
#
#     model = model.to(device)
#     # model = nn.DataParallel(model).to(device)
#
#     # def lambda_rule(iters):
#     #     lr_l = (1 - float(iters) / cfg.loops_train) ** 0.9
#     #     return lr_l
#     # def lambda_rule(iters):
#     #     lr_l = 1 - max(0, iters - 1400) / float(1600)
#     #     return lr_l
#
#     # def lambda_rule(epochs):
#     #     lr_scale = 1
#     #     if epochs < 15:
#     #         lr_scale = min(1., float(epochs + 1) / 15.)
#     #     return lr_scale
#
#     # scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[800, 2500], gamma=0.5)
#     # scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer=optimizer, lr_lambda=lambda_rule)
#     # scheduler = torch.optim.lr_scheduler.StepLR(optimizer=optimizer, step_size=cfg.step_size, gamma=0.7)
#
#     if not os.path.exists(cfg.logs):
#         os.makedirs(cfg.logs)
#
#     # warm up with datasets concatentated and randomly sampled
#     # (different domains in one batch)
#     # if cfg.warm:
#     #     loss_dict = {
#     #         'loss_feat_mix': AverageMeter()
#     #     }
#     #     for epoch in range(1, cfg.loops_warm):
#     #         cfg.__setattr__('current_lr', format(optimizer.param_groups[0]['lr'], '.3e'))
#     #         print('warming...epoch {0}'.format(epoch))
#     #         for _, loss in loss_dict.items():
#     #             loss.reset()
#     #         print(Fore.CYAN, 'log_path:{0}'.format(cfg.log_path), Style.RESET_ALL)
#     #         train_warm(cfg, model, train_loader_conc, loss_fn, optimizer, scheduler, loss_dict)
#     #         test_workflow(cfg, model, epoch, test_loader, writer)
#
#     # outfile = os.path.join(cfg.model_path, 'best_model.tar')
#     # torch.save({'seed': cfg.seed, 'unseen': cfg.unseen_index, 'state': model.state_dict()}, outfile)
#
#     best_acc = 0.0
#     best_acc_from_val = 0.0
#     best_val = 0.0
#     num_sources = len(train_datasets_isolated)
#     cfg.__setattr__('num_sources', num_sources)
#     splits_in_batch = split_integer(cfg.batch_size, len(train_datasets_isolated))
#     cfg.__setattr__('splits', splits_in_batch)
#     loss_dict = {
#         'loss_ds': AverageMeter(),
#         'loss_main_ds': AverageMeter(),
#         'loss_ib_feat': AverageMeter(),
#         'loss_feat_mix': AverageMeter(),
#         'loss_ib_cls': AverageMeter()
#     }
#
#     model.train()
#     bn_eval(model, cfg)
#     if isinstance(model, nn.DataParallel):
#         model = model.module
#
#     for ite in range(cfg.loops_train):
#         cfg.__setattr__('current_lr', format(optimizer.param_groups[0]['lr'], '.3e'))
#         start_time = time.time()
#
#         if 'dropout' in cfg.model and cfg.change_dropout_rate:
#             if random.random() > cfg.ib_rate:
#                 model.change_dropout(model.main_net, 0)
#             else:
#                 model.change_dropout(model.main_net, cfg.ib_rate)
#
#         if cfg.ds and ite < cfg.ds_ite_end:
#             model.train()
#             bn_eval(model, cfg)
#             train_ds(cfg=cfg, model=model, train_loader=train_datasets_isolated, loss_fn=loss_fn, optimizer=optimizer,
#                      ite=ite, loss_dict=loss_dict, writer=writer)
#
#         ib_flag = cfg.ib_feat and ite >= cfg.ib_ite_start and random.random() <= cfg.ib_rate
#         if ib_flag:
#             train_ib(cfg=cfg, model=model, train_loader=train_datasets_isolated, loss_fn=loss_fn, optimizer=optimizer,
#                      ite=ite, loss_dict=loss_dict, writer=writer)
#         elif cfg.mix:
#             train_mix(cfg=cfg, model=model, train_loader=train_datasets_isolated, loss_fn=loss_fn, optimizer=optimizer,
#                       loss_dict=loss_dict, ite=ite, writer=writer)
#
#         if cfg.main_ds:
#             train_main_ds(cfg, model, train_datasets_isolated, loss_fn, optimizer, loss_dict, ite, writer)
#
#         if ite > 0 and ite % 100 == 0:
#             print_errors(ite, cfg, loss_dict, optimizer)
#             print('iters: {0}/{1}'.format(ite, cfg.loops_train),
#                   Fore.CYAN, 'log_path:{0}'.format(cfg.log_path), Style.RESET_ALL
#                   )
#             print('100 ites training time: {0}s'.format((time.time() - start_time) * 100))
#
#             ### test domain specific networks on val sets
#             val_acc = val_workflow(cfg, model, val_loader_isolated, ite, log_dir='logs/')
#
#             ### test main model
#             test_acc = test_workflow(cfg, model, ite, test_loader, writer, val_acc)
#             if val_acc > best_val:
#                 best_val = val_acc
#                 best_acc_from_val = test_acc
#
#             if test_acc > best_acc:
#                 best_acc = test_acc
#                 if cfg.save_model:
#                     outfile = os.path.join(cfg.model_path, 'best_model_for_{0}.tar'.format(cfg.test_domain))
#                     torch.save({'ite': ite, 'seed': cfg.seed, 'unseen': cfg.unseen_index,
#                                 'state': model.state_dict()},
#                                outfile)
#
#             print(Fore.YELLOW,
#                   ' best dg test accuracy is //////{0}//////, best dg test acc from val is //////{1}////// (val:{2})'
#                   .format(round(best_acc * 100, 3), round(best_acc_from_val * 100, 3), round(best_val * 100, 3)),
#                   Style.RESET_ALL)
#
#         # train_params.assert_buffer_is_valid()
#         scheduler.step()
#
#     if writer is not None:
#         writer.close()
#
#
# def train_mix(cfg, model, train_loader, loss_fn, optimizer, loss_dict, ite, writer):
#     total_loss = 0
#     for i in range(cfg.num_sources):
#
#         list_imgs = []
#         list_labels = []
#
#         for index, dataset in enumerate(train_loader):
#             images, labels, domains, img_paths = dataset.get_images_labels_batch(batch_size=cfg.splits[index],
#                                                                                  domain=cfg.train_domains[index])
#             images, labels = images.to(device), labels.to(device)
#             list_imgs.append(images)
#             list_labels.append(labels)
#
#         imgs_mixed = torch.cat(list_imgs)
#         tgts_mixed = torch.cat(list_labels)
#
#         if cfg.shuffle:
#             imgs_index = [i for i in range(len(imgs_mixed))]
#             random.shuffle(imgs_index)
#             imgs_mixed = imgs_mixed[imgs_index]
#             tgts_mixed = tgts_mixed[imgs_index]
#
#         result = model(imgs_mixed)
#
#         loss_mix = loss_fn(result['cls'], tgts_mixed) * cfg.alpha_mix
#         loss_mix, loss_dict = log_error(cfg, loss=loss_mix, loss_key='loss_feat_mix', loss_dict=loss_dict,
#                                         alpha=cfg.alpha_mix)
#         total_loss += loss_mix
#
#     optimizer.zero_grad()
#     total_loss.backward()
#     optimizer.step()
#
#     if ite % 100 == 0:
#         writer.add_image(
#             'ib/train_image_mix',
#             torchvision.utils.make_grid(imgs_mixed.data[:6], 3, normalize=True), global_step=ite)
#
#
# def train_main_ds(cfg, model, train_loader, loss_fn, optimizer, loss_dict, ite, writer):
#     total_loss = 0
#     for index, dataset in enumerate(train_loader):
#         images, labels, domains, img_paths = dataset.get_images_labels_batch(batch_size=cfg.batch_size,
#                                                                              domain=cfg.train_domains[index])
#         images, labels = images.to(device), labels.to(device)
#
#         result = model(images)
#         loss_main_ds = loss_fn(result['cls'], labels) * cfg.alpha_main_ds
#         loss_main_ds, loss_dict = log_error(cfg, loss=loss_main_ds, loss_key='loss_main_ds', loss_dict=loss_dict,
#                                             alpha=cfg.alpha_mix)
#
#         if cfg.ds_op:
#             optimizer.zero_grad()
#             loss_main_ds.backward()
#             optimizer.step()
#         else:
#             total_loss += loss_main_ds
#
#     if not cfg.ds_op:
#         optimizer.zero_grad()
#         total_loss.backward()
#         optimizer.step()
#
#
# # def train_warm(cfg, model, train_loader, loss_fn, optimizer, scheduler, loss_dict=None, ite_nums=None, isolate_datasets=None, ite=None, writer=None):
# #
# #     model.train()
# #     bn_eval(model, cfg)
# #     num = 0
# #     start_time = time.time()
# #     for i, (images, targets) in enumerate(train_loader):
# #         if i > 0 and i % ite_nums == 0:
# #             train_ib(cfg=cfg, model=model, train_datasets=isolate_datasets, loss_fn=loss_fn,
# #                                  loss_fn_focal=loss_fn, optimizer=optimizer, scheduler=scheduler, ite=ite, loss_dict=loss_dict, writer=writer)
# #         num += images.size()[0]
# #         bs = images.size()[0]
# #         images, labels = images.to(device), targets.to(device)
# #         result = model(images)
# #
# #         loss_mix = loss_fn(result['cls'], labels) * cfg.alpha_mix
# #         loss_mix, loss_dict = log_error(cfg, loss=loss_mix,
# #                                               loss_key='loss_feat_mix', loss_dict=loss_dict, bs=bs,
# #                                               alpha=cfg.alpha_mix)
# #         optimizer.zero_grad()
# #         loss_mix.backward()
# #         optimizer.step()
# #
# #         if i % 30 == 0:
# #             writer.add_image(
# #                 'ib/train_image_mix',
# #                 torchvision.utils.make_grid(images.data, 3, normalize=True), global_step=ite)
# #
# #     print('one epoch training time: {0}'.format(time.time() - start_time))
#
# # print('train images num: ', num)
# # print_errors(ite, cfg, loss_dict, optimizer)
#
# def train_ib(cfg, model, train_loader, loss_fn, optimizer,
#              ite, loss_dict=None, writer=None):
#     candidates = np.arange(0, len(train_loader))
#     bs = cfg.batch_size
#     total_loss = 0
#
#     if cfg.ib_act_area == 'random':
#         act_area = np.random.choice(['similar', 'different'], size=1)[0]
#     else:
#         act_area = cfg.ib_act_area
#
#     if cfg.ib_layers[0] < 0:
#         ib_layers = np.random.choice([0, 4], size=1)
#     else:
#         ib_layers = cfg.ib_layers
#
#     # if ite > 0 and ite % 500 == 0:
#     # ib_layers = ib_layers[: ite // 500 + 1]
#     # if ite > 0 and ite % 500 == 0:
#     #     fix_layer = ite // 500 - 1
#     #     print('fix_layer: layer{0}'.format(fix_layer))
#     #     model.fix_grad(model.main_net.__getattr__('layer{index}'.format(index=fix_layer)))
#
#     for index, dataset in enumerate(train_loader):
#
#         par_index_list = list(set([index]) ^ set(candidates))
#
#         if cfg.ib_interact == 'single':
#             index_par = np.random.choice(par_index_list, size=1)
#         else:
#             index_par = par_index_list
#
#         images, labels, domains, img_paths = dataset.get_images_labels_batch(batch_size=bs,
#                                                                              domain=cfg.train_domains[index],
#                                                                              update=True)
#         images, labels = images.to(device), labels.to(device)
#
#         if 'g' in cfg.ib_type:
#             result = model.forward_ib_grad(images, index_par=index_par, labels=labels, act_area=act_area,
#                                            ib_layers=ib_layers)
#             # if ite % 100 == 0:
#             #     feat_ori = result['feat'][0]
#             #     feat_ds = result['ds_' + str(index)]['feat'][0]
#             #
#             #     hmp_main_ori = feat_ori.sum(dim=0).detach().cpu().numpy()
#             #     hmp_main_ori = model._normalize(hmp_main_ori)
#             #     hmp_main_ori = cv2.resize(hmp_main_ori, (224, 224))
#             #     # hmp_main_ori = to_pil_image(activation_map, mode='F')
#             #
#             #     # ds act
#             #     hmp_ds = feat_ds.sum(dim=0).detach().cpu().numpy()
#             #     hmp_ds = model._normalize(hmp_ds)
#             #     hmp_ds = cv2.resize(hmp_ds, (224, 224))
#             #     # hmp_ds = to_pil_image(activation_map, mode='F')
#             #
#             #     # main ib
#             #     hmp_main_ib = feat_ib.sum(dim=0).detach().cpu().numpy()
#             #     hmp_main_ib = self._normalize(hmp_main_ib)
#             #     hmp_main_ib = cv2.resize(hmp_main_ib, (224, 224))
#             #
#             #     # img = Image.open(img_paths[0]).convert('RGB').resize((224, 224), Image.ANTIALIAS)
#             #
#             #     img = io.imread(img_paths[0])
#             #     img = np.float32(cv2.resize(img, (224, 224))) / 255
#             #
#             #     result['hmp_ds'], _ = cam_util.gen_cam(img, hmp_ds)
#             #     # result['hmp_ds'] = overlay_mask(img, hmp_ds)
#             #     result['hmp_main_ori'], _ = cam_util.gen_cam(img, hmp_main_ori)
#             #     result['hmp_main_ib'], _ = cam_util.gen_cam(img, hmp_main_ib)
#             #     result['image'] = images[0]
#             #     result['index_par'] = index_par
#         elif 'ga' in cfg.ib_type:
#             result = model.forward_ib_grad_alternate(images, index_par=index_par, labels=labels, act_area=act_area,
#                                                      ib_layers=ib_layers)
#         else:
#             raise ValueError('ib type {0} not supported!'.format(cfg.ib_type))
#
#         loss_ib_feat = loss_fn(result['cls'], labels) * cfg.alpha_ib
#         loss_ib_feat, loss_dict = log_error(cfg, loss=loss_ib_feat, loss_key='loss_ib_feat', loss_dict=loss_dict,
#                                             alpha=cfg.alpha_ib)
#         if cfg.ds_op:
#             optimizer.zero_grad()
#             loss_ib_feat.backward()
#             optimizer.step()
#         else:
#             total_loss += loss_ib_feat
#
#         # ds
#         # if cfg.ds and ite < cfg.ds_ite_end:
#         #     model.train()
#         #     bn_eval(model, cfg)
#         #     if not cfg.detach_ds:
#         #         x = result['layer'+str(cfg.shared_layer)]
#         #         result_ds = model.forward_ds_higher(x, domain_index=index)
#         #     else:
#         #         result_ds = model.forward_ds(images, domain_index=index)
#         #
#         #     loss_ds = loss_fn(result_ds['cls'], labels) * cfg.alpha_ds
#         #     loss_ds, loss_dict = log_error(cfg, loss=loss_ds, loss_key='loss_ds', loss_dict=loss_dict, alpha=cfg.alpha_ds)
#         #     total_loss += loss_ds
#
#         if ite > 0 and ite % 100 == 0:
#             for key, val in result.items():
#                 if 'ib_preserve_rate' in key:
#                     print('{0}: training {1} with ds_{2} {3} is {4}'.format(
#                         key, cfg.train_domains[index],
#                         cfg.train_domains[index_par[0]], act_area,
#                         round(val, 5)))
#
#         if ite % 100 == 0:
#             writer.add_image(
#                 'ib/train_image_ib',
#                 torchvision.utils.make_grid(images.data[:6], 3, normalize=True), global_step=ite + index)
#
#     if not cfg.ds_op:
#         optimizer.zero_grad()
#         total_loss.backward()
#         optimizer.step()
#
#
# def train_ds(cfg, model, train_loader, loss_fn, optimizer,
#              ite, loss_dict=None, writer=None):
#     bs = cfg.batch_size
#     total_loss = 0
#     for index, dataset in enumerate(train_loader):
#
#         images, labels, domains, img_paths = dataset.get_images_labels_batch(batch_size=bs,
#                                                                              domain=cfg.train_domains[index],
#                                                                              update=True)
#         images, labels = images.to(device), labels.to(device)
#
#         if not cfg.detach_ds:
#             x = model.main_net.forward_features(images, return_layer=cfg.shared_layer)
#             x = x['feat']
#             result_ds = model.forward_ds_higher(x, domain_index=index)
#         else:
#             result_ds = model.forward_ds(images, domain_index=index)
#
#         loss_ds = loss_fn(result_ds['cls'], labels) * cfg.alpha_ds
#         loss_ds, loss_dict = log_error(cfg, loss=loss_ds, loss_key='loss_ds', loss_dict=loss_dict, alpha=cfg.alpha_ds)
#         total_loss += loss_ds
#
#     optimizer.zero_grad()
#     total_loss.backward()
#     optimizer.step()
#
#     # if ite % 100 == 0:
#     #     writer.add_image(
#     #                 'ib/train_image_ds',
#     #                 torchvision.utils.make_grid(images.data[:6], 3, normalize=True), global_step=ite+index)
#
#     # model.train()
#     # bn_eval(model, cfg)
#     # for i, (images, labels) in enumerate(dataset_conc):
#     #
#     #     if i > cfg.num_sources * (1-cfg.ib_rate) // cfg.ib_rate - 1:
#     #         break
#     #
#     #     images, labels = images.to(device), labels.to(device)
#     #     result = model(images)
#     #     loss_feat_mix = loss_fn(result['cls'], labels) * cfg.alpha_mix
#     #     loss_feat_mix, loss_dict = log_error(cfg, loss=loss_feat_mix,
#     #                                   loss_key='loss_feat_mix', loss_dict=loss_dict, bs=bs, alpha=cfg.alpha_mix)
#     #
#     #     optimizer.zero_grad()
#     #     loss_feat_mix.backward()
#     #     optimizer.step()
#
#     # if ite > 0:
#
#
# def log_error(cfg, loss, loss_key, loss_dict, alpha=1):
#     if cfg.flood > 0:
#         flood = alpha * cfg.flood
#         loss = (loss - flood).abs() + flood
#
#     loss_dict[loss_key].update(loss.item())
#     return loss, loss_dict
#
#
# def print_errors(ite, cfg, loss_dict, optimizer, writer=None):
#     print()
#     losses_avg = []
#     losses_cur = []
#     for key, loss in loss_dict.items():
#         losses_avg.append('{0}: {1} '.format(key, round(loss.avg, 5)))
#         # print('{0}: {1}'.format(key, round(loss.avg, 5)))
#         # f = open(os.path.join(cfg.logs, '{}.txt'.format(key)), mode='a')
#         # f.write('seed:{}, ite:{} :{}\n'.format(cfg.seed, ite, loss.avg))
#         # f.close()
#
#     losses_avg = ' /// '.join([loss for loss in losses_avg])
#     print('Loss avg iters: {0}/{1}'.format(ite, cfg.loops_train), Fore.YELLOW + losses_avg, Style.RESET_ALL)
#
#     for _, loss in loss_dict.items():
#         loss.reset()
#
#     for param_group in optimizer.param_groups:
#         lr = param_group['lr']
#         print(optimizer.__class__.__name__, ' lr = %.8f' % lr)
#
#
# def test_workflow(cfg, model, ite, test_loader, writer=None, val_acc=None):
#     start_time = time.time()
#     print_key_params(cfg)
#
#     # print('*' * 15 + ' unseen domain:', Fore.MAGENTA + ' ///{0}/// '.format(test_domain) + Style.RESET_ALL, '*' * 15 )
#     # test(cfg=cfg, model=model, data_loader=val_loader, ite=ite, log_dir=cfg.logs, log_prefix='val')
#     acc = test(cfg=cfg, model=model, data_loader=test_loader, ite=ite, log_dir=cfg.logs, log_prefix='dg_test',
#                writer=writer, val_acc=val_acc)
#     writer.add_scalar('ib/' + cfg.test_domain, round(acc * 100, 3), global_step=ite)
#     print('********* test time: {0}s ************'.format(time.time() - start_time))
#     return acc
#
#
# def test(cfg, model, data_loader, ite, log_prefix, log_dir='logs/', writer=None, val_acc=None):
#     # switch on the network test mode
#     model.eval()
#     preds_list = []
#     targets_list = []
#     num = 0
#     for i, (images, targets) in enumerate(data_loader):
#         num += images.size()[0]
#         images, labels = images.to(device), targets.to(device)
#         result = model(images)
#
#         predictions = result['Predictions'].cpu().data.numpy()
#         preds_list.extend(predictions)
#         # targets_list.extend(targets)
#         targets_list.extend(targets.cpu().data.numpy())
#
#         if ite % 100 == 0:
#             writer.add_image(
#                 'ib/test',
#                 torchvision.utils.make_grid(images.data[:6], 3, normalize=True), global_step=ite)
#
#     assert len(preds_list) == len(targets_list)
#     accuracy = compute_accuracy(predictions=preds_list, labels=targets_list)
#     head = Fore.MAGENTA if 'dg_test' in log_prefix else ''
#     tail = Style.RESET_ALL if 'dg_test' in log_prefix else ''
#     print(head, 'seed: {0}, lr: {1}'.format(cfg.seed, cfg.current_lr),
#           'image num: {0}'.format(num),
#           '------{prefix}------:{accuracy} ({domain} - {ite}/{loops} - val:{val_acc})'.format(
#               prefix=log_prefix, accuracy=round(accuracy * 100, 3), domain=cfg.test_domain,
#               ite=ite, loops=cfg.loops_train, val_acc=round(val_acc * 100, 3)), tail)
#
#     if not os.path.exists(log_dir):
#         os.makedirs(log_dir)
#
#     f = open(os.path.join(log_dir, '{}.txt'.format(log_prefix)), mode='a')
#     # f.write('unseen domain: ', self.test_domain)
#     f.write('seed:{}, ite:{}, accuracy:{}\n'.format(cfg.seed, ite, accuracy))
#     f.close()
#     return accuracy
#
#
# def print_key_params(cfg):
#     # print(Fore.RED + 'key params: seed: {0}, weight_decay: {1}, batch_size: {2}, '
#     #                  'shared_layer: {3}'.format(cfg.seed, cfg.weight_decay, cfg.batch_size, cfg.shared_layer),
#     #       Style.RESET_ALL)
#
#     infos = []
#     for key in sorted(set(cfg.keys()) ^ set(cfg.not_print_keys)):
#         val = cfg.__getitem__(key)
#         if hasattr(val, '__call__'):
#             continue
#         infos.append('{0}: {1}'.format(key, val))
#
#     print('params: ', Fore.RED + ", ".join(str(i) for i in infos) + Style.RESET_ALL)
#     print('sys args: ', cfg.sys_args)
#
#
# def val_workflow(cfg, model, val_loaders, ite, log_dir='logs/'):
#     # switch on the network test mode
#     model.eval()
#     num = 0
#     ds_preds_list = {i: [[] for _ in range(len(val_loaders))] for i in range(len(cfg.train_domains))}
#     targets_list = [[] for _ in range(len(val_loaders))]
#     acc = []
#     print('=' * 30, 'valiation', '=' * 30)
#     for index, loader in enumerate(val_loaders):
#         main_pred = []
#
#         for i, (images, targets) in enumerate(loader):
#             num += images.size()[0]
#             images, labels = images.to(device), targets.to(device)
#
#             for domain in range(len(cfg.train_domains)):
#                 result = model.forward_ds(images, domain_index=domain)
#                 predictions = result['Predictions'].cpu().data.numpy()
#                 ds_preds_list[domain][index].extend(predictions)
#
#             result = model(images)
#             predictions = result['Predictions'].cpu().data.numpy()
#             main_pred.extend(predictions)
#             targets_list[index].extend(targets.cpu().data.numpy())
#
#         accs = []
#         for i, d in enumerate(cfg.train_domains):
#             accuracy = compute_accuracy(predictions=ds_preds_list[i][index], labels=targets_list[index])
#             accs.append('{0}: {1}'.format(d, round(accuracy * 100, 3)))
#         accuracy_main = compute_accuracy(predictions=main_pred, labels=targets_list[index])
#         print('domain specific *{0}* val (img num: {1}) --| '.format(cfg.train_domains[index], len(loader.dataset)),
#               ' | '.join([acc for acc in accs]), ' ||| main: {0}'.format(round(accuracy_main * 100, 3)))
#         acc.append(accuracy_main)
#
#     val_acc = np.mean(acc)
#     print('=' * 30, 'main net val mean: {0}'.format(val_acc), '=' * 30)
#     return val_acc
#
#
# def compute_accuracy(predictions, labels):
#     if np.ndim(labels) == 2:
#         y_true = np.argmax(labels, axis=-1)
#     else:
#         y_true = labels
#     accuracy = accuracy_score(y_true=y_true, y_pred=np.argmax(predictions, axis=-1))
#     return accuracy
#
#
# def bn_eval(model, cfg):
#     # if cfg.bn_eval:
#     # for l in range(0, 5):\
#     # if cfg.bn_eval_main:
#     #
#     #     for n, m in model.named_modules():
#     #         if isinstance(m, nn.BatchNorm2d) and 'main_net' in n:
#     #             m.eval()
#     #             m.weight.requires_grad = False
#     #             m.bias.requires_grad = False
#     # else:
#     #     shared_layer = 'layer' + str(cfg.shared_layer)
#     #     module = model.main_net.__getattr__(shared_layer)
#     #     for m in module:
#     #         if isinstance(m, nn.BatchNorm2d):
#     #             m.eval()
#     #             m.weight.requires_grad = False
#     #             m.bias.requires_grad = False
#
#     if cfg.bn_eval_main:
#         for l in range(cfg.eval_layer_start, cfg.eval_layer_end):
#             module = model.main_net.__getattr__('layer{index}'.format(index=l))
#             for m in module:
#                 if isinstance(m, nn.BatchNorm2d):
#                     m.eval()
#                     m.weight.requires_grad = False
#                     m.bias.requires_grad = False
#
#     if cfg.bn_eval_ds:
#         for n, m in model.named_modules():
#             if isinstance(m, nn.BatchNorm2d) and 'ds_nets' in n:
#                 m.eval()
#                 m.weight.requires_grad = False
#                 m.bias.requires_grad = False
#
#     # for l in range(cfg.shared_layer + 1, 5):
#     #     module = model.main_net.__getattr__('layer{index}'.format(index=l))
#     #     for m in module:
#     #         if isinstance(m, nn.BatchNorm2d):
#     #             m.eval()
#     #             m.weight.requires_grad = False
#     #             m.bias.requires_grad = False
#     #
#     # for ds_net in model.ds_nets:
#     #     for m in ds_net.modules():
#     #         if isinstance(m, nn.BatchNorm2d):
#     #             m.eval()
#     #             m.weight.requires_grad = False
#     #             m.bias.requires_grad = False
#
#
# def load_checkpoint(cfg, net, load_path):
#     state_checkpoint = torch.load(load_path, map_location=lambda storage, loc: storage.cuda())
#     print('loading {0} ...'.format(load_path))
#     if os.path.isfile(load_path):
#
#         state_dict = net.state_dict()
#         # cfg.__setattr__('resume_ite', state_checkpoint['ite'])
#
#         ignore_list = list()
#         for k, v in state_checkpoint['state'].items():
#             k = str.replace(k, 'module.', '')
#             # print('loading: ', k)
#             if k in state_dict.keys() and v.size() == state_dict[k].size():
#                 state_dict[k] = v
#                 # print('loaded: ', k)
#             else:
#                 ignore_list.append(k)
#
#         print('fail loaded: ', ignore_list)
#         net.load_state_dict(state_dict)
#     else:
#         raise ValueError('No checkpoint found at {0}'.format(load_path))
#
#
# def get_scheduler(cfg, optimizer):
#     if cfg.scheduler == 'lambda_exp':
#
#         def lambda_rule(iters):
#             lr_l = (1 - float(iters) / cfg.loops_train) ** 0.9
#             lr_l = max(0.2, lr_l)
#             return lr_l
#
#         # def lambda_rule(iters):
#         #     lr_l = 1 - max(0, iters - 1400) / float(1600)
#         #     return lr_l
#
#         # def lambda_rule(epochs):
#         #     lr_scale = 1
#         #     if epochs < 15:
#         #         lr_scale = min(1., float(epochs + 1) / 15.)
#         #     return lr_scale
#
#         scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer=optimizer, lr_lambda=lambda_rule)
#     elif cfg.scheduler == 'lambda_linear':
#
#         def lambda_rule(iters):
#             lr_l = 1 - max(0, iters - 1000) / float(2000)
#             return lr_l
#
#         scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer=optimizer, lr_lambda=lambda_rule)
#
#     elif cfg.scheduler == 'step':
#         scheduler = torch.optim.lr_scheduler.StepLR(optimizer=optimizer, step_size=cfg.loops_train * 2 // 3, gamma=0.5)
#     elif cfg.scheduler == 'multi_step':
#         scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer,
#                                                          milestones=[cfg.loops_train // 3, cfg.loops_train * 2 // 3],
#                                                          gamma=0.5)
#
#     return scheduler
#
#
# class FocalLoss(nn.Module):
#     r"""
#         This criterion is a implemenation of Focal Loss, which is proposed in
#         Focal Loss for Dense Object Detection.
#
#             Loss(x, class) = - \alpha (1-softmax(x)[class])^gamma \log(softmax(x)[class])
#
#         The losses are averaged across observations for each minibatch.
#
#         Args:
#             alpha(1D Tensor, Variable) : the scalar factor for this criterion
#             gamma(float, double) : gamma > 0; reduces the relative loss for well-classiﬁed examples (p > .5),
#                                    putting more focus on hard, misclassiﬁed examples
#             size_average(bool): By default, the losses are averaged over observations for each minibatch.
#                                 However, if the field size_average is set to False, the losses are
#                                 instead summed for each minibatch.
#
#
#     """
#
#     def __init__(self, class_num, alpha=None, gamma=2, size_average=True):
#         super(FocalLoss, self).__init__()
#         if alpha is None:
#             self.alpha = torch.ones(class_num, 1)
#         else:
#             self.alpha = torch.Tensor(alpha)
#         self.gamma = gamma
#         self.class_num = class_num
#         self.size_average = size_average
#
#     def forward(self, inputs, targets):
#         N = inputs.size(0)
#         C = inputs.size(1)
#         P = F.softmax(inputs)
#
#         class_mask = inputs.data.new(N, C).fill_(0)
#         class_mask = Variable(class_mask)
#         ids = targets.view(-1, 1)
#         class_mask.scatter_(1, ids.data, 1.)
#         # print(class_mask)
#
#         if inputs.is_cuda and not self.alpha.is_cuda:
#             self.alpha = self.alpha.cuda()
#         alpha = self.alpha[ids.data.view(-1)]
#
#         probs = (P * class_mask).sum(1).view(-1, 1)
#
#         log_p = probs.log()
#         # print('probs size= {}'.format(probs.size()))
#         # print(probs)
#
#         batch_loss = -alpha * (torch.pow((1 - probs), self.gamma)) * log_p
#         # print('-----bacth_loss------')
#         # print(batch_loss)
#
#         if self.size_average:
#             loss = batch_loss.mean()
#         else:
#             loss = batch_loss.sum()
#         return loss
#
#
# def split_integer(m, n):
#     assert n > 0
#     quotient = int(m / n)
#     remainder = m % n
#     if remainder > 0:
#         return [quotient] * (n - remainder) + [quotient + 1] * remainder
#     if remainder < 0:
#         return [quotient - 1] * -remainder + [quotient] * (n + remainder)
#     return [quotient] * n
#
#
# # def cam_act(model, conv_layer='layer1'):
#
#
# if __name__ == "__main__":
#     # d = loadmat('/home/dudapeng/workspace/datasets/VLSC/' + 'Caltech101.mat')
#     torch.set_default_tensor_type('torch.cuda.FloatTensor')
#     # send_msg_by_serverchan('test', 'dg_test新高')
#     main()
#
# # if cfg.ib_cls and ite >= cfg.ib_ite and random.random() <= cfg.ib_rate:
# #     # if ib_flag and random.random() <= cfg.ib_rate:
# #     if 'ib_flatten' in result.keys():
# #         cls = model.main_net.fc(result['ib_flatten'].detach())
# #     else:
# #         train_index_list = list(set([index]) ^ set(candidates))
# #         index_par = np.random.choice(train_index_list, size=1)[0]
# #         result_ds = model.forward_ds(images, domain_index=index_par)
# #         cls = model.main_net.fc(result_ds['flatten'].detach())
# #     loss_ib_cls = loss_fn(cls, labels) * cfg.alpha_ib_cls
# #     total_loss += loss_ib_cls
# #     loss_dict['loss_ib_cls'].update(loss_ib_cls.item(), bs)
#
# # if ite % 100 == 0 and 'hmp_ds' in result.keys():
# #     img = result['image']
# #     hmp_ds = result['hmp_ds']
# #     hmp_main_ori = result['hmp_main_ori']
# #     hmp_main_ib = result['hmp_main_ib']
# #     heat_cam = torch.cat([img.cpu(), loader_img(hmp_main_ori), loader_img(hmp_ds), loader_img(hmp_main_ib)],
# #                          2)
# #
# #     writer.add_image(
# #         'ib/cam_' + cfg.train_domains[index] + '_ds_{0}_actlayer_{1}'.format(cfg.train_domains[index_par[0]], ib_layers[0]),
# #         torchvision.utils.make_grid(heat_cam.data, 3, normalize=True), global_step=ite)
#
# # optimizer.zero_grad()
# # total_loss.backward()
# # optimizer.step()
#
# # images, labels, domains, img_paths = dataset.get_images_labels_batch(batch_size=splits[index], domain=cfg.train_domains[index])
# # images, labels = images.to(device), labels.to(device)
# # imgs_mixed_list.append(images)
# # tgts_mixed_list.append(labels)
# # if cfg.mix and not ib_flag:
#
# # if ite == 2001:
# #     outfile = os.path.join(cfg.model_path, 'best_model.tar')
# #     torch.save({'ite': ite, 'seed': cfg.seed, 'unseen': cfg.unseen_index,
# #                     'state': model.state_dict()},
# #                    outfile)
# #     # print('before 300:')
# #     # test_workflow(cfg, model, ite, val_loader, test_loader, test_domain)
# #     break
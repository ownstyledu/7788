import os
import random
import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset


class Manual_BatchSampler_Dataset(Dataset):

    def __init__(self, flags, path, dom, shuffle=True, transforms=None):
        self.flag = flags
        self.transforms = transforms
        classes, class_to_idx = self.find_classes(path)
        self.domain = dom
        # int_to_class = dict(zip(range(len(classes)), classes))
        list_data = self.make_dataset(path, class_to_idx)
        self.imgs_paths = list(np.array(list_data)[:, 0])
        self.labels = list(np.array(list_data)[:, 1])
        self.file_num_train = len(list_data)

        if shuffle:
            self.imgs_paths, self.labels = self.shuffle_data(self.imgs_paths, self.labels)
        self.batch_size = flags.batch_size
        self.current_index = -1
        self.epoch = 0
        # print('training images num: ', self.__len__())

    def find_classes(self, dir):
        classes = [d for d in os.listdir(dir) if os.path.isdir(os.path.join(dir, d))]
        classes.sort()
        class_to_idx = {classes[i]: i for i in range(len(classes))}
        return classes, class_to_idx

    def make_dataset(self, path, class_to_idx):
        images = []
        dir = os.path.expanduser(path)
        for target in sorted(os.listdir(dir)):
            d = os.path.join(dir, target)
            if not os.path.isdir(d):
                continue

            for root, _, fnames in sorted(os.walk(d)):
                for fname in sorted(fnames):
                    path = os.path.join(root, fname)
                    item = (path, class_to_idx[target])
                    images.append(item)
        return images

    def get_images_labels_batch(self, loop=True, batch_size=None, domain=None, update=True):

        bs = self.batch_size if batch_size is None else batch_size

        images_paths = []
        labels = []
        domains = []
        if not update:
            tmp = self.current_index

        for index in range(bs):
            self.current_index += 1

            if self.current_index > self.file_num_train - 1:

                if loop:
                    self.current_index %= self.file_num_train
                    self.epoch += 1
                    # print('shuffle {0}: {1} / {2}'.format(domain, self.file_num_train, self.epoch))
                    self.imgs_paths, self.labels = self.shuffle_data(samples=self.imgs_paths, labels=self.labels)
                else:
                    break

            images_paths.append(self.imgs_paths[self.current_index])
            labels.append(self.labels[self.current_index])
            domains.append(domain)

        imgs = []
        labs = []
        for i, img_p in enumerate(images_paths):
            img = Image.open(img_p).convert('RGB')
            assert np.ndim(img) == 3
            assert np.shape(img)[2] == 3
            img = self.transforms(img)
            imgs.append(img)
            labs.append(torch.from_numpy(np.array(int(labels[i]))))

        images = torch.stack(imgs)
        labels = torch.stack(labs)

        if not update:
            self.current_index = tmp

        return images, labels, domains, images_paths

    def shuffle_data(self, samples, labels):
        num = len(labels)
        shuffle_index = np.random.permutation(np.arange(num))
        shuffled_samples = np.array(samples)[shuffle_index]
        shuffled_labels = np.array(labels)[shuffle_index]
        return list(shuffled_samples), list(shuffled_labels)

    def __len__(self):
        return len(self.imgs_paths)


class Domain_Specific_Dataset(Dataset):

    def __init__(self, flags, path, dom, transforms=None):
        self.flag = flags
        self.transforms = transforms
        classes, class_to_idx = self.find_classes(path)
        self.domain = dom
        list_data = self.make_dataset(path, class_to_idx)
        self.imgs_paths = list(np.array(list_data)[:, 0])
        self.labels = list(np.array(list_data)[:, 1])
        self.file_num_train = len(list_data)

    def find_classes(self, dir):
        classes = [d for d in os.listdir(dir) if os.path.isdir(os.path.join(dir, d))]
        classes.sort()
        class_to_idx = {classes[i]: i for i in range(len(classes))}
        return classes, class_to_idx

    def make_dataset(self, path, class_to_idx):
        images = []
        dir = os.path.expanduser(path)
        for target in sorted(os.listdir(dir)):
            d = os.path.join(dir, target)
            if not os.path.isdir(d):
                continue

            for root, _, fnames in sorted(os.walk(d)):
                for fname in sorted(fnames):
                    path = os.path.join(root, fname)
                    item = (path, class_to_idx[target])
                    images.append(item)
        return images

    def __len__(self):
        return len(self.imgs_paths)

    def __getitem__(self, index):

        if index >= self.file_num_train:
            index %= self.file_num_train
        path = self.imgs_paths[index]
        img = Image.open(path).convert('RGB')
        img = self.transforms(img)
        label = torch.from_numpy(np.array(int(self.labels[index])))
        # return img, label
        return img, label, self.domain, path

class MultiDataset(Dataset):

    def __init__(self, *datasets):
        # assert all(tensors[0].size(0) == tensor.size(0) for tensor in tensors)
        self.datasets = datasets

    def __getitem__(self, index):
        return tuple(dataset[index] for dataset in self.datasets)

    def __len__(self):
        # return sum([len(d) for d in self.datasets])
        return max([len(d) for d in self.datasets])

# class ConcatDataset(Dataset):
#     def __init__(self, *datasets):
#         self.datasets = datasets
#
#     def __getitem__(self, i):
#         for d in self.datasets:
#             if i < len(d):
#                 d[i]
#             else:
#                 d[random.randint(0, len(d) - 1)]
#
#
#         return tuple(d[i] if i < len(d) else d[random.randint(0, len(d)-1)] for d in self.datasets)
#
#     def __len__(self):
#         return max([len(d) for d in self.datasets])
#
# class Subset(torch.utils.data.Dataset):
#     def __init__(self, dataset, limit):
#         indices = torch.randperm(len(dataset))[:limit]
#         self.dataset = dataset
#         self.indices = indices
#
#     def __getitem__(self, idx):
#         return self.dataset[self.indices[idx]]
#
#     def __len__(self):
#         return len(self.indices)


import torch
import torch.nn as nn
import os
try:
    from torch.hub import load_state_dict_from_url
except ImportError:
    from torch.utils.model_zoo import load_url as load_state_dict_from_url

model_urls = {
    'alexnet': 'https://download.pytorch.org/models/alexnet-owt-4df8aa71.pth',
}

class AlexNet(nn.Module):

    def __init__(self, num_classes=1000):
        super(AlexNet, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=11, stride=4, padding=2),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
            nn.Conv2d(64, 192, kernel_size=5, padding=2),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
            nn.Conv2d(192, 384, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(384, 256, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2, padding=0, dilation=1),
        )

        self.classifier = nn.Sequential(
            nn.Dropout(0.5),
            nn.Linear(256 * 6 * 6, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Linear(4096, num_classes),
        )

    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x


def alexnet(pretrained=False, progress=True, **kwargs):
    r"""AlexNet model architecture from the
    `"One weird trick..." <https://arxiv.org/abs/1404.5997>`_ paper.

    Args:
        pretrained (bool): If True, returns a model pre-trained on ImageNet
        progress (bool): If True, displays a progress bar of the download to stderr
    """
    model = AlexNet(**kwargs)
    if pretrained:
        state_dict = load_state_dict_from_url(model_urls['alexnet'],
                                              progress=progress)
        model.load_state_dict(state_dict)
    return model

def alexnet_bn(pretrained=False, progress=True, **kwargs):
    model = AlexNet_BN()
    if pretrained:
        load_path = os.path.join('/home/dudapeng/workspace/train_imagenet/model_best_224.pth.tar')
        state_checkpoint = torch.load(load_path, map_location=lambda storage, loc: storage.cuda())
        state_dict = model.state_dict()
        for k, v in state_checkpoint['state_dict'].items():
            k = str.replace(k, 'module.', '')
            if k in state_dict.keys() and v.size() == state_dict[k].size():
                state_dict[k] = v

        model.load_state_dict(state_dict)

    return model

class AlexNet_BN(nn.Module):
    def __init__(self, num_classes=1000):
        super(AlexNet_BN, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 96, kernel_size=11, stride=4, padding=2, bias=False),
            nn.BatchNorm2d(96),
            nn.ReLU(inplace=True),

            nn.Conv2d(96, 256, kernel_size=5, stride=1, padding=2, bias=False),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),

            nn.Conv2d(256, 384, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(384),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),

            nn.Conv2d(384, 384, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(384),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),

            nn.Conv2d(384, 512, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
        )
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(512, num_classes)

    def forward(self, x):
        x = self.features(x)
        x = self.avgpool(x).flatten(1)
        x = self.fc(x)
        return x


def _load_checkpoint(net, load_path, key='net', keep_fc=False):
    state_checkpoint = torch.load(load_path, map_location=lambda storage, loc: storage.cuda())
    print('loading {0} ...'.format(load_path))
    if os.path.isfile(load_path):
        state_dict = net.state_dict()

        if key is not None:
            state_checkpoint = state_checkpoint[key]

        for k, v in state_checkpoint.items():
            k = str.replace(k, 'module.', '')
            print('loading: ', k)
            if k in state_dict.keys():
                if not keep_fc and ('fc' in k or 'evaluator' in k or 'cls_criterion' in k or 'conc_seg' in k):
                    continue
                state_dict[k] = v
                print('loaded: ', k)

        net.load_state_dict(state_dict)
    else:
        raise ValueError('No checkpoint found at {0}'.format(load_path))
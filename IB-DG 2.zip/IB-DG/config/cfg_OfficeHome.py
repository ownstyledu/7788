from config.cfg_PACS import Config_PACS


class Config_Office_Home(Config_PACS):

    data_root = '/home/dudapeng/workspace/datasets/OfficeHomeDataset_10072016'
    num_classes = 65

    train_suffix = ''
    val_suffix = ''
    test_suffix = ''
    val = False
    test = True

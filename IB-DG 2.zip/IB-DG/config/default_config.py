from datetime import datetime
class DefaultConfig:
    seed = 1
    test_every = 100
    batch_size = 10
    num_classes = 7
    step_size = 3000
    bn_eval = True
    loops_train = 15
    unseen_index = 0
    warm = True
    loops_warm = 15

    lr = 0.001
    weight_decay = 0.0001
    momentum = 0.9
    writer_path = '/data1/dudapeng/summary/ib/'
    logs = 'logs'
    model = 'resnet18'
    data_root = ''
    resume = False
    resume_path = ''
    tsne = False
    ib_regular = False

    def parse(self, kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

    def print_args(self):
        print('user config:')
        for k, v in self.__class__.__dict__.items():
            if not k.startswith('__'):
                print(k, ':', getattr(self, k))

    def keys(self):
        attrs = []
        for p in dir(self):
            if '__' not in p:
                attrs.append(p)
        return attrs

    def __getitem__(self, item):

        return getattr(self, item)

    not_print_keys = [
        'starttime', 'resume_path', 'log_path', 'model_path', 'not_print_keys', 'num_classes',
        'test_domain', 'train_domains', 'unseen_index', 'writer_path', 'data_root', 'logs', 'momentum',
        'task_name', 'test_every', 'sys_args'
    ]
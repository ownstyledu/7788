from config.default_config import DefaultConfig
from datetime import datetime
from functools import reduce

class Config_PACS(DefaultConfig):

    seed = 1
    model = 'resnet50'  # resnet18 | alexnet
    ds_model = 'resnet18'
    size = 224
    pretrained = True
    resume = False
    norm = 'bn'
    bn_eval_main = False
    bn_eval_ds = False
    eval_layer_start = 0
    eval_layer_end = 5
    optimizer = 'sgd'
    # data_root = '/extracephonline/medai_data_vvv/dudapeng/ft_local/PACS'
    data_root = '/home/dudapeng/workspace/datasets/PACS'
    lr = 0.003
    lr_ds = 0.002
    weight_decay = 0.0001
    batch_size = 48
    warm = False
    warm_ds = False
    loops_warm = 15
    loops_train = 30
    scheduler = 'lambda_exp'
    print_freq = 1
    nproc_per_node = 1
    vis = False
    vis_cam = False
    gate_strategy = 'channel'
    gpu_num = 1
    local_rank = 0
    local_world_size = 1
    mp = False
    gpu_ids = [1,3]
    port = 8001
    train_index = []
    exclude_index = [4]
    self_chlg = False
    mask = 'main'
    gate_level = 'channel'
    gate_pos = 'hook_f'
    gradual_ib = False
    bp = 'ds'
    multi_task = False
    detach_layers = [-100]
    p=0.5
    ds_pretrain = 'imagenet'
    random_layers=[1,3]
    spatial_dropout=False
    val = True
    test = True

    train_suffix = 'train'
    val_suffix = 'val'
    test_suffix = 'test'

    ib_ite_start = 0
    ds_ite_start = 0
    ds_ite_end = 500
    mix_ite_end = 10000
    shared_layer = 0
    shuffle = True
    starttime = datetime.now().strftime('%b%d_%H-%M-%S')
    resume_path = './checkpoints/trecg/cam_baseline_content_4_adam_in__enhance_resnet18_place_AtoB_Rec_SUNRGBD_CLS_center_crop_gpus_1_Jun28_12-41-53/checkpoint.pth'
    task_name = ''
    ib_type = 'g'
    ib_act_area = 'similar'
    ib_interact = 'single'
    ib_layers = [1]
    cross_domain = 'a'
    ib_fc_layers = [-1]
    ib_rate = 0.1
    change_dropout_rate = False
    detach_ds = True
    flood = -1.0
    ds_op = False
    dropout = False
    scale_drop = True
    save_model = False
    drop_rate=0.3

    main_ds = False
    ds = False
    mix = False
    ib_feat = False
    mix_ib = False

    alpha_ib = 1
    alpha_ib_cls = 0.1
    alpha_ds = 1.0
    alpha_mix = 1.0
    alpha_main_ds = 1.0





from config.cfg_PACS import Config_PACS


class Config_VLCS(Config_PACS):

    data_root = '/home/dudapeng/workspace/datasets/VLCS'
    num_classes = 5
